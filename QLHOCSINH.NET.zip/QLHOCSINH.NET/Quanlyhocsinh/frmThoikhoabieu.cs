﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class frmThoikhoabieu : Form
    {
        // Cờ trạng thái
        private bool isAdding = false;
        private bool isLoaded = false;

        // Biến lưu trữ ID và Vai trò người dùng hiện tại
        private int currentUserId = 0;
        private string currentUserRole = "admin"; // Mặc định admin

        // --- CONSTRUCTOR ---
        public frmThoikhoabieu()
        {
            InitializeComponent();
        }

        public frmThoikhoabieu(int userId, string role)
        {
            InitializeComponent();
            this.currentUserId = userId;
            this.currentUserRole = role.Trim().ToLower(); // Chuẩn hóa chuỗi
        }

        // --- FORM LOAD ---
        private void frmThoikhoabieu_Load(object sender, EventArgs e)
        {
            isLoaded = false; // Tạm khóa sự kiện ComboBox

            // 1. Cấu hình giao diện theo Vai trò
            if (currentUserRole == "admin")
            {
                // ADMIN: Hiện tất cả, Load tất cả lớp
                panelInputArea.Visible = true; // Panel chứa các ô nhập liệu
                cboChonLop2.Visible = true;    // Hiện ComboBox lọc
                LoadComboBoxLop_Admin();       // Load full lớp
                SetButtonState(true);
            }
            else if (currentUserRole == "teacher")
            {
                // GIÁO VIÊN: Ẩn nhập liệu, nhưng HIỆN ComboBox lọc
                panelInputArea.Visible = false;
                cboChonLop2.Visible = true;     // QUAN TRỌNG: Phải để Visible = true

                // Load danh sách lớp mà GV này có dạy
                LoadComboBoxLop_GiaoVien();
            }
            else // Học sinh
            {
                // HỌC SINH: Ẩn hết, chỉ xem lưới
                panelInputArea.Visible = false;
                cboChonLop2.Visible = false;    // Học sinh không cần lọc lớp (vì chỉ xem lớp mình)
            }

            // 2. Tải dữ liệu lên lưới (Grid)
            LoadTKB(); // Hàm này sẽ tự động kiểm tra role để lọc dữ liệu

            isLoaded = true; // Mở khóa sự kiện
        }

        // --- HÀM 1: LOAD DANH SÁCH LỚP CHO ADMIN (Full) ---
        private void LoadComboBoxLop_Admin()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                string sql = "SELECT id, tenlop FROM lop ORDER BY tenlop";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Thêm dòng "Tất cả"
                DataRow allRow = dt.NewRow();
                allRow["id"] = -1; // Dùng -1 thay vì DBNull cho dễ xử lý số
                allRow["tenlop"] = "--- Tất cả các lớp ---";
                dt.Rows.InsertAt(allRow, 0);

                cboChonLop2.DataSource = dt;
                cboChonLop2.DisplayMember = "tenlop";
                cboChonLop2.ValueMember = "id";
                cboChonLop2.SelectedIndex = 0;
            }
        }

        // --- HÀM 2: LOAD DANH SÁCH LỚP CHO GIÁO VIÊN (Chỉ lớp mình dạy) ---
        private void LoadComboBoxLop_GiaoVien()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                // Chỉ lấy các lớp có trong thời khóa biểu của GV này
                // Dùng DISTINCT để loại bỏ trùng lặp
                string sql = @"SELECT DISTINCT l.id, l.tenlop 
                               FROM lop l 
                               JOIN thoikhoabieu tkb ON l.id = tkb.lop_id 
                               WHERE tkb.magv = @gvId 
                               ORDER BY l.tenlop";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@gvId", currentUserId);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Thêm dòng "Tất cả"
                DataRow allRow = dt.NewRow();
                allRow["id"] = -1;
                allRow["tenlop"] = "--- Tất cả lớp dạy ---";
                dt.Rows.InsertAt(allRow, 0);

                cboChonLop2.DataSource = dt;
                cboChonLop2.DisplayMember = "tenlop";
                cboChonLop2.ValueMember = "id";
                cboChonLop2.SelectedIndex = 0;
            }
        }

        // --- HÀM 3: LOAD DỮ LIỆU CHÍNH (Logic lọc quan trọng) ---
        // SỬA: Thêm tham số keywordThu vào cuối (mặc định là null)
        private void LoadTKB(int? lopIdFilter = null, string keywordThu = null)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();

                string sql = @"
        SELECT tkb.id, l.tenlop, gv.hoten AS giaovien, mh.tenmonhoc AS monhoc,
                tkb.tiet, tkb.thu
        FROM thoikhoabieu tkb
        JOIN lop l ON l.id = tkb.lop_id
        JOIN giaovien gv ON gv.magv = tkb.magv
        JOIN monhoc mh ON mh.id = tkb.monhoc_id
        WHERE 1 = 1 ";

                SqlCommand cmd = new SqlCommand(sql, conn);

                // --- 1. PHÂN QUYỀN DỮ LIỆU (Giữ nguyên logic cũ) ---
                if (currentUserRole == "admin")
                {
                    if (lopIdFilter.HasValue && lopIdFilter.Value > 0)
                    {
                        sql += " AND tkb.lop_id = @lopId";
                        cmd.Parameters.AddWithValue("@lopId", lopIdFilter.Value);
                    }
                }
                else if (currentUserRole == "teacher")
                {
                    sql += " AND tkb.magv = @gvId";
                    cmd.Parameters.AddWithValue("@gvId", currentUserId);

                    if (lopIdFilter.HasValue && lopIdFilter.Value > 0)
                    {
                        sql += " AND tkb.lop_id = @lopId";
                        cmd.Parameters.AddWithValue("@lopId", lopIdFilter.Value);
                    }
                }
                else if (currentUserRole == "student")
                {
                    sql += " AND tkb.lop_id = (SELECT lop_id FROM hocsinh WHERE mahs = @hsId)";
                    cmd.Parameters.AddWithValue("@hsId", currentUserId);
                }

                // --- 2. LOGIC TÌM KIẾM THEO THỨ (MỚI THÊM) ---
                if (!string.IsNullOrEmpty(keywordThu))
                {
                    // Dùng LIKE để tìm kiếm tương đối (vd nhập "2" vẫn ra "Thứ 2")
                    sql += " AND tkb.thu LIKE @thu";
                    cmd.Parameters.AddWithValue("@thu", "%" + keywordThu + "%");
                }

                // Sắp xếp: Tên lớp -> Thứ -> Tiết
                sql += " ORDER BY l.tenlop, tkb.thu, tkb.tiet";

                cmd.CommandText = sql;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvTKB.DataSource = dt;

                // Định dạng GridView (Giữ nguyên)
                if (dt.Columns.Contains("id")) dgvTKB.Columns["id"].Visible = false;
                dgvTKB.Columns["tenlop"].HeaderText = "Lớp";
                dgvTKB.Columns["giaovien"].HeaderText = "Giáo viên";
                dgvTKB.Columns["monhoc"].HeaderText = "Môn học";
                dgvTKB.Columns["tiet"].HeaderText = "Tiết";
                dgvTKB.Columns["thu"].HeaderText = "Thứ";

                dgvTKB.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvTKB.ClearSelection();
            }
        }

        // --- SỰ KIỆN: CHỌN COMBOBOX (Đã mở quyền cho GV) ---
        private void cboChonLop2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isLoaded || currentUserRole == "student") return;

            // Xóa ô tìm kiếm khi đổi lớp để tránh hiểu nhầm
            txtTimKiem.Text = "";

            int selectedId = -1;
            if (cboChonLop2.SelectedValue != null)
            {
                int.TryParse(cboChonLop2.SelectedValue.ToString(), out selectedId);
            }

            if (selectedId > 0)
                LoadTKB(selectedId, null); // Truyền null vào tham số thứ
            else
                LoadTKB(null, null);
        }

        // --- CÁC CHỨC NĂNG THÊM/SỬA/XÓA (Admin only) ---
        private void btnThem_Click(object sender, EventArgs e)
        {
            isAdding = true;
            SetButtonState(false);
            ClearInputFields();
            txtLop.ReadOnly = false;
            txtLop.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dgvTKB.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn dòng cần sửa!", "Thông báo");
                return;
            }
            isAdding = false;
            SetButtonState(false);
            txtLop.ReadOnly = false;
            txtGiaoVien.Focus();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvTKB.CurrentRow == null) return;

            if (MessageBox.Show("Bạn chắc chắn muốn xóa tiết học này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    int id = Convert.ToInt32(dgvTKB.CurrentRow.Cells["id"].Value);
                    using (SqlConnection conn = KetNoi.GetConnection())
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("DELETE FROM thoikhoabieu WHERE id = @id", conn);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Đã xóa thành công!");

                    // Refresh lại dữ liệu
                    LoadTKB(GetCurrentSelectedLopId());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu đầu vào cơ bản
            if (string.IsNullOrWhiteSpace(txtLop.Text) ||
                string.IsNullOrWhiteSpace(txtGiaoVien.Text) ||
                string.IsNullOrWhiteSpace(txtMon.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Lớp, Giáo viên và Môn học!", "Cảnh báo");
                return;
            }

            try
            {
                using (SqlConnection conn = KetNoi.GetConnection())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    // Logic truy vấn con (Sub-query) để lấy ID từ Tên
                    // Lưu ý: Tên nhập vào phải chính xác 100%
                    string subQueryLop = "(SELECT id FROM lop WHERE tenlop = @tenlop)";
                    string subQueryGV = "(SELECT magv FROM giaovien WHERE hoten = @tengv)";
                    string subQueryMon = "(SELECT id FROM monhoc WHERE tenmonhoc = @tenmon)";

                    if (isAdding)
                    {
                        cmd.CommandText = $@"INSERT INTO thoikhoabieu (lop_id, magv, monhoc_id, tiet, thu) 
                                             VALUES ({subQueryLop}, {subQueryGV}, {subQueryMon}, @tiet, @thu)";
                    }
                    else
                    {
                        int id = Convert.ToInt32(dgvTKB.CurrentRow.Cells["id"].Value);
                        cmd.CommandText = $@"UPDATE thoikhoabieu SET 
                                             lop_id = {subQueryLop}, 
                                             magv = {subQueryGV}, 
                                             monhoc_id = {subQueryMon}, 
                                             tiet = @tiet, 
                                             thu = @thu 
                                             WHERE id = @id";
                        cmd.Parameters.AddWithValue("@id", id);
                    }

                    // Truyền tham số (Dùng Trim để xóa khoảng trắng thừa)
                    cmd.Parameters.AddWithValue("@tenlop", txtLop.Text.Trim());
                    cmd.Parameters.AddWithValue("@tengv", txtGiaoVien.Text.Trim());
                    cmd.Parameters.AddWithValue("@tenmon", txtMon.Text.Trim());
                    cmd.Parameters.AddWithValue("@tiet", txtTiet.Text.Trim());
                    cmd.Parameters.AddWithValue("@thu", txtThu.Text.Trim());

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Lưu dữ liệu thành công!");
                        isAdding = false;
                        SetButtonState(true);
                        ClearInputFields();
                        LoadTKB(GetCurrentSelectedLopId()); // Refresh
                    }
                    else
                    {
                        MessageBox.Show("Không lưu được! Có thể tên Lớp, Giáo viên hoặc Môn học không tồn tại chính xác.", "Lỗi dữ liệu");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hệ thống: " + ex.Message);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            isAdding = false;
            SetButtonState(true);
            ClearInputFields();
        }

        // --- SỰ KIỆN CELL CLICK (Đổ dữ liệu lên ô nhập) ---
        private void dgvTKB_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvTKB.Rows.Count)
            {
                DataGridViewRow row = dgvTKB.Rows[e.RowIndex];
                // Dùng toán tử ?. để tránh lỗi null
                txtLop.Text = row.Cells["tenlop"].Value?.ToString();
                txtGiaoVien.Text = row.Cells["giaovien"].Value?.ToString();
                txtMon.Text = row.Cells["monhoc"].Value?.ToString();
                txtTiet.Text = row.Cells["tiet"].Value?.ToString();
                txtThu.Text = row.Cells["thu"].Value?.ToString();
            }
        }

        // --- TÌM KIẾM ---
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            // 1. Lấy từ khóa
            string tuKhoaThu = txtTimKiem.Text.Trim();

            // 2. NẾU Ô TÌM KIẾM RỖNG -> LOAD LẠI DANH SÁCH (REFRESH)
            if (string.IsNullOrEmpty(tuKhoaThu))
            {
                // Lấy ID lớp đang chọn hiện tại (để không bị mất bộ lọc lớp)
                int? currentLopId = GetCurrentSelectedLopId();

                // Gọi hàm Load với từ khóa là null để hiện tất cả các thứ
                LoadTKB(currentLopId, null);

                return; // Dừng lại, không chạy code bên dưới nữa
            }

            // 3. NẾU CÓ NHẬP CHỮ -> TÌM KIẾM
            // Lấy ID lớp đang chọn để kết hợp vừa lọc lớp vừa tìm thứ
            int? lopDangChon = GetCurrentSelectedLopId();

            // Gọi hàm LoadTKB với cả 2 tham số
            LoadTKB(lopDangChon, tuKhoaThu);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // --- CÁC HÀM TIỆN ÍCH ---
        private void SetButtonState(bool viewMode)
        {
            // Chỉ áp dụng cho Admin
            if (currentUserRole != "admin") return;

            btnThem.Enabled = viewMode;
            btnSua.Enabled = viewMode;
            btnXoa.Enabled = viewMode;
            btnLuu.Enabled = !viewMode;
            btnHuy.Enabled = !viewMode;

            txtLop.ReadOnly = true; // Mặc định khóa, chỉ mở khi bấm Thêm/Sửa
            txtGiaoVien.ReadOnly = viewMode;
            // ... Khóa các ô khác tương tự nếu cần
        }

        private void ClearInputFields()
        {
            txtLop.Clear();
            txtGiaoVien.Clear();
            txtMon.Clear();
            txtTiet.Clear();
            txtThu.Clear();
        }

        // Helper để lấy ID đang chọn trong combo
        private int? GetCurrentSelectedLopId()
        {
            if (cboChonLop2.SelectedValue != null)
            {
                if (int.TryParse(cboChonLop2.SelectedValue.ToString(), out int id) && id > 0)
                    return id;
            }
            return null;
        }
    }
}