﻿namespace Quanlyhocsinh
{
    partial class Trangchu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnTrangchu = new System.Windows.Forms.Button();
            this.btnQuanlyhocsinh = new System.Windows.Forms.Button();
            this.btnQuanlygiaovien = new System.Windows.Forms.Button();
            this.btnQuanlydiem = new System.Windows.Forms.Button();
            this.btnTKB = new System.Windows.Forms.Button();
            this.btnDangxuat = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel1.BackgroundImage = global::Quanlyhocsinh.Properties.Resources.school;
            this.flowLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.btnTrangchu);
            this.flowLayoutPanel1.Controls.Add(this.btnQuanlyhocsinh);
            this.flowLayoutPanel1.Controls.Add(this.btnQuanlygiaovien);
            this.flowLayoutPanel1.Controls.Add(this.btnQuanlydiem);
            this.flowLayoutPanel1.Controls.Add(this.btnTKB);
            this.flowLayoutPanel1.Controls.Add(this.btnDangxuat);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1259, 729);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // btnTrangchu
            // 
            this.btnTrangchu.BackColor = System.Drawing.Color.Transparent;
            this.btnTrangchu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrangchu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangchu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTrangchu.Location = new System.Drawing.Point(3, 91);
            this.btnTrangchu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 5);
            this.btnTrangchu.Name = "btnTrangchu";
            this.btnTrangchu.Size = new System.Drawing.Size(264, 58);
            this.btnTrangchu.TabIndex = 9;
            this.btnTrangchu.Text = "Trang chủ";
            this.btnTrangchu.UseVisualStyleBackColor = false;
            this.btnTrangchu.Click += new System.EventHandler(this.btnTrangchu_Click_1);
            // 
            // btnQuanlyhocsinh
            // 
            this.btnQuanlyhocsinh.BackColor = System.Drawing.Color.Transparent;
            this.btnQuanlyhocsinh.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnQuanlyhocsinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanlyhocsinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanlyhocsinh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnQuanlyhocsinh.Location = new System.Drawing.Point(3, 156);
            this.btnQuanlyhocsinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 5);
            this.btnQuanlyhocsinh.Name = "btnQuanlyhocsinh";
            this.btnQuanlyhocsinh.Size = new System.Drawing.Size(264, 58);
            this.btnQuanlyhocsinh.TabIndex = 9;
            this.btnQuanlyhocsinh.Text = "Quản lý học sinh";
            this.btnQuanlyhocsinh.UseVisualStyleBackColor = false;
            this.btnQuanlyhocsinh.Click += new System.EventHandler(this.btnQuanlyhocsinh_Click);
            // 
            // btnQuanlygiaovien
            // 
            this.btnQuanlygiaovien.BackColor = System.Drawing.Color.Transparent;
            this.btnQuanlygiaovien.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnQuanlygiaovien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanlygiaovien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanlygiaovien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnQuanlygiaovien.Location = new System.Drawing.Point(3, 221);
            this.btnQuanlygiaovien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 5);
            this.btnQuanlygiaovien.Name = "btnQuanlygiaovien";
            this.btnQuanlygiaovien.Size = new System.Drawing.Size(264, 58);
            this.btnQuanlygiaovien.TabIndex = 10;
            this.btnQuanlygiaovien.Text = "Quản lý giáo viên";
            this.btnQuanlygiaovien.UseVisualStyleBackColor = false;
            this.btnQuanlygiaovien.Click += new System.EventHandler(this.btnQuanlygiaovien_Click_1);
            // 
            // btnQuanlydiem
            // 
            this.btnQuanlydiem.BackColor = System.Drawing.Color.Transparent;
            this.btnQuanlydiem.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnQuanlydiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanlydiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanlydiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnQuanlydiem.Location = new System.Drawing.Point(3, 286);
            this.btnQuanlydiem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 5);
            this.btnQuanlydiem.Name = "btnQuanlydiem";
            this.btnQuanlydiem.Size = new System.Drawing.Size(264, 58);
            this.btnQuanlydiem.TabIndex = 11;
            this.btnQuanlydiem.Text = "Quản lý điểm";
            this.btnQuanlydiem.UseVisualStyleBackColor = false;
            this.btnQuanlydiem.Click += new System.EventHandler(this.btnQuanlydiem_Click_1);
            // 
            // btnTKB
            // 
            this.btnTKB.BackColor = System.Drawing.Color.Transparent;
            this.btnTKB.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTKB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTKB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTKB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTKB.Location = new System.Drawing.Point(3, 351);
            this.btnTKB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 5);
            this.btnTKB.Name = "btnTKB";
            this.btnTKB.Size = new System.Drawing.Size(264, 58);
            this.btnTKB.TabIndex = 13;
            this.btnTKB.Text = "Thời khóa biểu";
            this.btnTKB.UseVisualStyleBackColor = false;
            this.btnTKB.Click += new System.EventHandler(this.btnTKB_Click_1);
            // 
            // btnDangxuat
            // 
            this.btnDangxuat.BackColor = System.Drawing.Color.Transparent;
            this.btnDangxuat.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDangxuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangxuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangxuat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDangxuat.Location = new System.Drawing.Point(3, 416);
            this.btnDangxuat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 5);
            this.btnDangxuat.Name = "btnDangxuat";
            this.btnDangxuat.Size = new System.Drawing.Size(264, 58);
            this.btnDangxuat.TabIndex = 13;
            this.btnDangxuat.Text = "Đăng xuất";
            this.btnDangxuat.UseVisualStyleBackColor = false;
            this.btnDangxuat.Click += new System.EventHandler(this.btnDangxuat_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1259, 83);
            this.panel1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Location = new System.Drawing.Point(365, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(529, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "HỆ THỐNG QUẢN LÝ HỌC SINH";
            // 
            // Trangchu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 729);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Trangchu";
            this.Text = "Trangchu";
            this.Load += new System.EventHandler(this.Trangchu_Load_1);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnQuanlyhocsinh;
        private System.Windows.Forms.Button btnQuanlygiaovien;
        private System.Windows.Forms.Button btnQuanlydiem;
        private System.Windows.Forms.Button btnTKB;
        private System.Windows.Forms.Button btnDangxuat;
        private System.Windows.Forms.Button btnTrangchu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}