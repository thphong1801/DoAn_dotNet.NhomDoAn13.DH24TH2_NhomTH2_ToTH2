﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient; // <-- BẠN PHẢI THÊM THƯ VIỆN NÀY
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quanlyhocsinh
{
    internal class KetNoi
    {
        //    Chúng ta dùng 'private static' để nó là biến của lớp, và không ai bên ngoài thay đổi được.
        private static string connectionString = @"Data Source=MSI\MSSQL;Initial Catalog=qlhs;Integrated Security=True";

        // 2. TẠO MỘT HÀM (METHOD) public VÀ static
        //    - 'public': Để các Form khác có thể gọi nó.
        //    - 'static': Để ta có thể gọi thẳng từ tên lớp (KetNoi.GetConnection())
        //                mà không cần tạo đối tượng (new KetNoi()).
        //    - 'SqlConnection': Kiểu dữ liệu trả về là một đối tượng kết nối.
        public static SqlConnection GetConnection()
        {
            // Hàm này chỉ làm một việc là tạo và trả về một đối tượng kết nối mới
            // với chuỗi kết nối đã định nghĩa ở trên.
            return new SqlConnection(connectionString);
        }
    }
}