﻿namespace Quanlyhocsinh
{
    partial class frmthongtincanhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.txtDiaChime = new System.Windows.Forms.TextBox();
            this.txtDiaChicha = new System.Windows.Forms.TextBox();
            this.txtSDTme = new System.Windows.Forms.TextBox();
            this.dgvBangDiem = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNgheme = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtTenme = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSDTcha = new System.Windows.Forms.TextBox();
            this.txtNghecha = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnQuaylai = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLop = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMaHS = new System.Windows.Forms.TextBox();
            this.txtHolot = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtHocLuc = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTrungBinh = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtTencha = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.cboHocKy = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBangDiem)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(168, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 20);
            this.label3.TabIndex = 79;
            this.label3.Text = "Thông tin phụ huynh";
            // 
            // txtDiaChime
            // 
            this.txtDiaChime.Location = new System.Drawing.Point(116, 183);
            this.txtDiaChime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChime.Name = "txtDiaChime";
            this.txtDiaChime.Size = new System.Drawing.Size(292, 22);
            this.txtDiaChime.TabIndex = 77;
            // 
            // txtDiaChicha
            // 
            this.txtDiaChicha.Location = new System.Drawing.Point(116, 91);
            this.txtDiaChicha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChicha.Name = "txtDiaChicha";
            this.txtDiaChicha.Size = new System.Drawing.Size(292, 22);
            this.txtDiaChicha.TabIndex = 73;
            // 
            // txtSDTme
            // 
            this.txtSDTme.Location = new System.Drawing.Point(116, 160);
            this.txtSDTme.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSDTme.Name = "txtSDTme";
            this.txtSDTme.Size = new System.Drawing.Size(292, 22);
            this.txtSDTme.TabIndex = 76;
            // 
            // dgvBangDiem
            // 
            this.dgvBangDiem.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvBangDiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBangDiem.Location = new System.Drawing.Point(15, 46);
            this.dgvBangDiem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvBangDiem.Name = "dgvBangDiem";
            this.dgvBangDiem.RowHeadersWidth = 62;
            this.dgvBangDiem.RowTemplate.Height = 28;
            this.dgvBangDiem.Size = new System.Drawing.Size(951, 146);
            this.dgvBangDiem.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.cboHocKy);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.dgvBangDiem);
            this.panel3.Location = new System.Drawing.Point(28, 238);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(980, 204);
            this.panel3.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(439, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Bảng điểm";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 16);
            this.label13.TabIndex = 52;
            this.label13.Text = "Tên cha:";
            // 
            // txtNgheme
            // 
            this.txtNgheme.Location = new System.Drawing.Point(116, 137);
            this.txtNgheme.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNgheme.Name = "txtNgheme";
            this.txtNgheme.Size = new System.Drawing.Size(292, 22);
            this.txtNgheme.TabIndex = 75;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 117);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 16);
            this.label17.TabIndex = 53;
            this.label17.Text = "Tên mẹ:";
            // 
            // txtTenme
            // 
            this.txtTenme.Location = new System.Drawing.Point(116, 114);
            this.txtTenme.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenme.Name = "txtTenme";
            this.txtTenme.Size = new System.Drawing.Size(292, 22);
            this.txtTenme.TabIndex = 74;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(22, 94);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(50, 16);
            this.label19.TabIndex = 54;
            this.label19.Text = "Địa chỉ:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(22, 71);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 16);
            this.label18.TabIndex = 56;
            this.label18.Text = "SĐT:";
            // 
            // txtSDTcha
            // 
            this.txtSDTcha.Location = new System.Drawing.Point(116, 69);
            this.txtSDTcha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSDTcha.Name = "txtSDTcha";
            this.txtSDTcha.Size = new System.Drawing.Size(292, 22);
            this.txtSDTcha.TabIndex = 72;
            // 
            // txtNghecha
            // 
            this.txtNghecha.Location = new System.Drawing.Point(116, 46);
            this.txtNghecha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNghecha.Name = "txtNghecha";
            this.txtNghecha.Size = new System.Drawing.Size(292, 22);
            this.txtNghecha.TabIndex = 71;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(22, 186);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 16);
            this.label21.TabIndex = 55;
            this.label21.Text = "Địa chỉ:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 49);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 16);
            this.label14.TabIndex = 58;
            this.label14.Text = "Nghề nghiệp:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.btnQuaylai);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1136, 632);
            this.panel1.TabIndex = 1;
            // 
            // btnQuaylai
            // 
            this.btnQuaylai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnQuaylai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuaylai.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQuaylai.Location = new System.Drawing.Point(520, 551);
            this.btnQuaylai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnQuaylai.Name = "btnQuaylai";
            this.btnQuaylai.Size = new System.Drawing.Size(97, 36);
            this.btnQuaylai.TabIndex = 62;
            this.btnQuaylai.Text = "Quay lại";
            this.btnQuaylai.UseVisualStyleBackColor = false;
            this.btnQuaylai.Click += new System.EventHandler(this.btnQuaylai_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label25.Location = new System.Drawing.Point(701, -22);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(178, 20);
            this.label25.TabIndex = 61;
            this.label25.Text = "Thông tin phụ huynh";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(404, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "THÔNG TIN CÁ NHÂN";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(44, 47);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1038, 500);
            this.panel2.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.textBox1);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.txtLop);
            this.panel6.Controls.Add(this.txtTen);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.txtChucVu);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.txtMaHS);
            this.panel6.Controls.Add(this.txtHolot);
            this.panel6.Controls.Add(this.txtDiaChi);
            this.panel6.Controls.Add(this.dtpNgaySinh);
            this.panel6.Controls.Add(this.cboGioiTinh);
            this.panel6.Location = new System.Drawing.Point(28, 17);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(477, 210);
            this.panel6.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(84, 213);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 16);
            this.label7.TabIndex = 79;
            this.label7.Text = "Mã HS:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(156, 210);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(238, 22);
            this.textBox1.TabIndex = 80;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(159, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 20);
            this.label2.TabIndex = 78;
            this.label2.Text = "Thông tin học sinh";
            // 
            // txtLop
            // 
            this.txtLop.Location = new System.Drawing.Point(90, 137);
            this.txtLop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLop.Name = "txtLop";
            this.txtLop.Size = new System.Drawing.Size(313, 22);
            this.txtLop.TabIndex = 67;
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(90, 69);
            this.txtTen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(313, 22);
            this.txtTen.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 45;
            this.label5.Text = "Mã HS:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 16);
            this.label8.TabIndex = 47;
            this.label8.Text = "Ngày sinh:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 71);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 16);
            this.label15.TabIndex = 46;
            this.label15.Text = "Tên:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 139);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 16);
            this.label16.TabIndex = 48;
            this.label16.Text = "Lớp:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 162);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 16);
            this.label20.TabIndex = 49;
            this.label20.Text = "Giới tính:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 186);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 16);
            this.label24.TabIndex = 50;
            this.label24.Text = "Chức vụ:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 16);
            this.label12.TabIndex = 51;
            this.label12.Text = "Địa chỉ:";
            // 
            // txtChucVu
            // 
            this.txtChucVu.Location = new System.Drawing.Point(90, 183);
            this.txtChucVu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(313, 22);
            this.txtChucVu.TabIndex = 69;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 16);
            this.label6.TabIndex = 60;
            this.label6.Text = "Họ lót:";
            // 
            // txtMaHS
            // 
            this.txtMaHS.Location = new System.Drawing.Point(90, 24);
            this.txtMaHS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaHS.Name = "txtMaHS";
            this.txtMaHS.Size = new System.Drawing.Size(313, 22);
            this.txtMaHS.TabIndex = 62;
            // 
            // txtHolot
            // 
            this.txtHolot.Location = new System.Drawing.Point(90, 46);
            this.txtHolot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtHolot.Name = "txtHolot";
            this.txtHolot.Size = new System.Drawing.Size(313, 22);
            this.txtHolot.TabIndex = 63;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(90, 91);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(313, 22);
            this.txtDiaChi.TabIndex = 66;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Location = new System.Drawing.Point(90, 114);
            this.dtpNgaySinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(313, 22);
            this.dtpNgaySinh.TabIndex = 64;
            // 
            // cboGioiTinh
            // 
            this.cboGioiTinh.FormattingEnabled = true;
            this.cboGioiTinh.Location = new System.Drawing.Point(90, 159);
            this.cboGioiTinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboGioiTinh.Name = "cboGioiTinh";
            this.cboGioiTinh.Size = new System.Drawing.Size(313, 24);
            this.cboGioiTinh.TabIndex = 65;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gainsboro;
            this.panel5.Controls.Add(this.txtHocLuc);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.txtTrungBinh);
            this.panel5.Location = new System.Drawing.Point(28, 451);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(980, 38);
            this.panel5.TabIndex = 2;
            // 
            // txtHocLuc
            // 
            this.txtHocLuc.Location = new System.Drawing.Point(758, 9);
            this.txtHocLuc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtHocLuc.Name = "txtHocLuc";
            this.txtHocLuc.Size = new System.Drawing.Size(96, 22);
            this.txtHocLuc.TabIndex = 82;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(680, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 20);
            this.label10.TabIndex = 81;
            this.label10.Text = "Học lực:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(76, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 20);
            this.label9.TabIndex = 79;
            this.label9.Text = "Trung bình cả năm:";
            // 
            // txtTrungBinh
            // 
            this.txtTrungBinh.Location = new System.Drawing.Point(252, 9);
            this.txtTrungBinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTrungBinh.Name = "txtTrungBinh";
            this.txtTrungBinh.Size = new System.Drawing.Size(96, 22);
            this.txtTrungBinh.TabIndex = 80;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.txtDiaChime);
            this.panel4.Controls.Add(this.txtDiaChicha);
            this.panel4.Controls.Add(this.txtSDTme);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.txtNgheme);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.txtTenme);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.txtSDTcha);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.txtNghecha);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.txtTencha);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Location = new System.Drawing.Point(532, 17);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(477, 210);
            this.panel4.TabIndex = 1;
            // 
            // txtTencha
            // 
            this.txtTencha.Location = new System.Drawing.Point(116, 24);
            this.txtTencha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTencha.Name = "txtTencha";
            this.txtTencha.Size = new System.Drawing.Size(292, 22);
            this.txtTencha.TabIndex = 70;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(22, 162);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 16);
            this.label22.TabIndex = 57;
            this.label22.Text = "SĐT:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(22, 139);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(87, 16);
            this.label23.TabIndex = 59;
            this.label23.Text = "Nghề nghiệp:";
            // 
            // cboHocKy
            // 
            this.cboHocKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHocKy.FormattingEnabled = true;
            this.cboHocKy.Items.AddRange(new object[] {
            "Học kỳ 1",
            "Hoc kỳ 2 ",
            "Cả năm"});
            this.cboHocKy.Location = new System.Drawing.Point(87, 16);
            this.cboHocKy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboHocKy.Name = "cboHocKy";
            this.cboHocKy.Size = new System.Drawing.Size(104, 28);
            this.cboHocKy.TabIndex = 64;
            this.cboHocKy.SelectedIndexChanged += new System.EventHandler(this.cboHocKy_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(20, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 20);
            this.label4.TabIndex = 63;
            this.label4.Text = "Học kỳ";
            // 
            // frmthongtincanhan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1136, 632);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmthongtincanhan";
            this.Text = "frmthongtincanhan";
            this.Load += new System.EventHandler(this.frmthongtincanhan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBangDiem)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDiaChime;
        private System.Windows.Forms.TextBox txtDiaChicha;
        private System.Windows.Forms.TextBox txtSDTme;
        private System.Windows.Forms.DataGridView dgvBangDiem;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNgheme;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtTenme;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtSDTcha;
        private System.Windows.Forms.TextBox txtNghecha;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnQuaylai;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtHocLuc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTrungBinh;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtTencha;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLop;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtMaHS;
        private System.Windows.Forms.TextBox txtHolot;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.ComboBox cboHocKy;
        private System.Windows.Forms.Label label4;
    }
}