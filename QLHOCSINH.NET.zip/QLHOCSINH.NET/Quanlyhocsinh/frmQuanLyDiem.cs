﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class frmQuanLyDiem : Form
    {
        private bool isLoaded = false;
        private int currentTeacherId = 0;

        // Constructor Mặc định (cho Admin)
        public frmQuanLyDiem()
        {
            InitializeComponent();
            txtThongKe.ReadOnly = true;
        }

        // Constructor mới (cho Teacher)
        public frmQuanLyDiem(int teacherId)
        {
            InitializeComponent();
            this.currentTeacherId = teacherId;
            txtThongKe.ReadOnly = true;
        }

        // Tải Lớp (ĐÃ LỌC THEO LỚP DẠY)
        private void LoadLop()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();

                string sql = @"
                    SELECT DISTINCT l.id, l.tenlop 
                    FROM lop l 
                    LEFT JOIN thoikhoabieu tkb ON tkb.lop_id = l.id 
                    WHERE 1=1";

                SqlCommand cmd = new SqlCommand(sql, conn);

                // Lọc lớp mình dạy bằng tkb.magv
                if (currentTeacherId > 0)
                {
                    sql += " AND tkb.magv = @teacherId";
                    cmd.Parameters.AddWithValue("@teacherId", currentTeacherId);
                }

                sql += " ORDER BY tenlop";
                cmd.CommandText = sql;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                DataRow allRow = dt.NewRow();
                allRow["id"] = DBNull.Value;
                allRow["tenlop"] = (currentTeacherId > 0) ? "--- Tất cả các lớp DẠY ---" : "--- Tất cả các lớp ---";
                dt.Rows.InsertAt(allRow, 0);

                cboChonLop.DisplayMember = "tenlop";
                cboChonLop.ValueMember = "id";
                cboChonLop.DataSource = dt;
            }

            cboChonLop.SelectedIndex = 0;
        }

        // Tải Điểm (ĐÃ SỬA LỖI VÀ THÊM LẠI BỘ LỌC)
        private void LoadDiem(int? lopId = null, string keyword = "")
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();

                // SQL Cơ bản (Giữ nguyên)
                string sql = @"
                SELECT 
                hs.mahs AS [Mã HS], 
                (hs.holot + ' ' + hs.ten) AS [Họ Tên], 
                l.tenlop AS [Lớp],
            
                MAX(CASE WHEN mh.tenmonhoc = N'Anh' THEN d.dtb_mon END) AS [Anh],
                MAX(CASE WHEN mh.tenmonhoc = N'GDCD' THEN d.dtb_mon END) AS [GDCD],
                MAX(CASE WHEN mh.tenmonhoc = N'Hóa' THEN d.dtb_mon END) AS [Hóa],
                MAX(CASE WHEN mh.tenmonhoc = N'Lý' THEN d.dtb_mon END) AS [Lý],
                MAX(CASE WHEN mh.tenmonhoc = N'Quốc phòng' THEN d.dtb_mon END) AS [Quốc phòng],
                MAX(CASE WHEN mh.tenmonhoc = N'Sinh' THEN d.dtb_mon END) AS [Sinh],
                MAX(CASE WHEN mh.tenmonhoc = N'Sử' THEN d.dtb_mon END) AS [Sử],
                MAX(CASE WHEN mh.tenmonhoc = N'Thể chất' THEN d.dtb_mon END) AS [Thể chất],
                MAX(CASE WHEN mh.tenmonhoc = N'Toán' THEN d.dtb_mon END) AS [Toán],
                MAX(CASE WHEN mh.tenmonhoc = N'Văn' THEN d.dtb_mon END) AS [Văn],
                MAX(CASE WHEN mh.tenmonhoc = N'Địa' THEN d.dtb_mon END) AS [Địa],

                AVG(d.dtb_mon) AS [ĐTB],
            
                hs.hocluc AS [Học Lực], 
                hs.hanhkiem AS [Hạnh Kiểm]
            
                FROM hocsinh hs
                JOIN lop l ON l.id = hs.lop_id
                LEFT JOIN diem d ON d.mahs = hs.mahs
                LEFT JOIN monhoc mh ON mh.id = d.monhoc_id 
                WHERE 1 = 1";

                SqlCommand cmd = new SqlCommand(sql, conn);

                // --- 1. LỌC GIÁO VIÊN (Giữ nguyên) ---
                if (currentTeacherId > 0)
                {
                    sql += " AND hs.lop_id IN (SELECT DISTINCT lop_id FROM thoikhoabieu WHERE magv = @teacherId)";
                    cmd.Parameters.AddWithValue("@teacherId", currentTeacherId);
                }

                // --- 2. XỬ LÝ TÌM KIẾM THEO TÊN (SỬA ĐOẠN NÀY) ---
                if (!string.IsNullOrWhiteSpace(keyword))
                {
                    // Tìm gần đúng theo Họ tên (ghép họ lót + tên)
                    // Ví dụ: Nhập "Tung" sẽ ra "Nguyen Van Tung", "Tung Son"...
                    sql += " AND (hs.holot + ' ' + hs.ten) LIKE @keyword";
                    cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                }
                // --- 3. NẾU KHÔNG TÌM KIẾM -> MỚI LỌC THEO LỚP ---
                else if (lopId.HasValue && lopId.Value != 0)
                {
                    sql += " AND hs.lop_id = @lopid";
                    cmd.Parameters.AddWithValue("@lopid", lopId.Value);
                }

                // --- GROUP BY và ORDER BY (Giữ nguyên) ---
                sql += @" 
                GROUP BY 
                    hs.mahs, hs.holot, hs.ten, l.tenlop, hs.hocluc, hs.hanhkiem 
                ORDER BY 
                    l.tenlop, hs.ten";

                cmd.CommandText = sql;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvDanhSachHocSinh.DataSource = dt;

                foreach (DataColumn col in dt.Columns)
                {
                    if (col.ColumnName == "ĐTB" || col.ColumnName == "Toán" || col.ColumnName == "Văn" /*...*/)
                    {
                        if (dgvDanhSachHocSinh.Columns.Contains(col.ColumnName))
                            dgvDanhSachHocSinh.Columns[col.ColumnName].DefaultCellStyle.Format = "N2";
                    }
                }

                if (dgvDanhSachHocSinh.Columns.Contains("Mã HS"))
                    dgvDanhSachHocSinh.Columns["Mã HS"].Visible = false;

                dgvDanhSachHocSinh.ClearSelection();
                ThongKe(dt);
            }
        }

        // SỬA 3: HÀM THỐNG KÊ (Sửa lỗi logic và tên cột)
        private void ThongKe(DataTable dt)
        {
            if (dt.Rows.Count == 0)
            {
                txtThongKe.Text = "Không có dữ liệu";
                return;
            }

            // Biến tính tổng điểm TB và sĩ số chung
            double tongDiemTB = 0;
            int hocSinhCoDiem = 0; // Số học sinh có điểm hợp lệ để tính TB

            // Biến đếm học lực
            int countGioi = 0;
            int countKha = 0;
            int countTrungBinh = 0;
            int countYeu = 0;

            int totalStudents = dt.Rows.Count; // Tổng sĩ số

            // 1. Duyệt qua DataRow và thống kê
            foreach (DataRow r in dt.Rows)
            {
                if (r["ĐTB"] != DBNull.Value && double.TryParse(r["ĐTB"].ToString(), out double dtb))
                {
                    tongDiemTB += dtb;
                    hocSinhCoDiem++;

                    // Xếp loại học lực
                    if (dtb >= 8.0)
                    {
                        countGioi++;
                    }
                    else if (dtb >= 6.5)
                    {
                        countKha++;
                    }
                    else if (dtb >= 5.0)
                    {
                        countTrungBinh++;
                    }
                    else
                    {
                        countYeu++;
                    }
                }
                else
                {
                    // Nếu không có điểm, mặc định coi là Yếu hoặc xếp loại riêng
                    // Tùy theo logic của trường, ở đây ta coi là Yếu (0-4.99)
                    // countYeu++; 
                    // KHÔNG NÊN ĐẾM vào Yếu nếu điểm là NULL. Chỉ đếm vào sĩ số chung.
                }
            }

            // 2. Tính Điểm TB Chung và Phần trăm
            double tbChung = (hocSinhCoDiem > 0) ? tongDiemTB / hocSinhCoDiem : 0;

            double percentGioi = (double)countGioi / totalStudents * 100;
            double percentKha = (double)countKha / totalStudents * 100;
            double percentTrungBinh = (double)countTrungBinh / totalStudents * 100;
            double percentYeu = (double)countYeu / totalStudents * 100;

            // 3. Hiển thị kết quả thống kê
            string thongKeText =
                $"Sĩ số: {totalStudents} | ĐTB Chung: {tbChung:0.00} " +
                $"Giỏi: {countGioi} ({percentGioi:0.0}%) | " +
                $"Khá: {countKha} ({percentKha:0.0}%) | " +
                $"TB: {countTrungBinh} ({percentTrungBinh:0.0}%) | " +
                $"Yếu: {countYeu} ({percentYeu:0.0}%)";

            txtThongKe.Text = thongKeText;
        }

        // Sự kiện Form Load
        private void frmQuanLyDiem_Load(object sender, EventArgs e)
        {
            LoadLop();
            isLoaded = true;
            cboChonLop_SelectedIndexChanged(null, null);
        }

        // Sự kiện ComboBox Lọc
        private void cboChonLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isLoaded) return;

            int? lopId = null;
            if (cboChonLop.SelectedValue != DBNull.Value && cboChonLop.SelectedValue != null)
            {
                if (int.TryParse(cboChonLop.SelectedValue.ToString(), out int id))
                {
                    lopId = id;
                }
            }

            txtTimKiem.Clear();
            LoadDiem(lopId, null);
        }

        // Nút Tìm kiếm
        private void button1_Click(object sender, EventArgs e)
        {
            string kw = txtTimKiem.Text.Trim();

            // ===========================================================
            // TRƯỜNG HỢP 1: Ô TÌM KIẾM RỖNG -> LOAD LẠI THEO LỚP ĐANG CHỌN
            // ===========================================================
            if (string.IsNullOrEmpty(kw))
            {
                // Lấy ID lớp đang chọn trong ComboBox
                int? lopId = null;
                if (cboChonLop.SelectedValue != null && cboChonLop.SelectedValue != DBNull.Value)
                {
                    if (int.TryParse(cboChonLop.SelectedValue.ToString(), out int id))
                    {
                        lopId = id;
                    }
                }
                // Load lại danh sách chỉ theo Lớp (bỏ qua từ khóa)
                LoadDiem(lopId, null);
                return;
            }
            // TRƯỜNG HỢP 2: CÓ NHẬP TÊN -> TÌM TRÊN TOÀN BỘ (HOẶC TOÀN KHỐI DẠY)
            // [Tùy chọn] Reset ComboBox về "Tất cả" để người dùng hiểu là đang tìm rộng
            if (cboChonLop.Items.Count > 0)
            {
                isLoaded = false;             // Khóa sự kiện
                cboChonLop.SelectedIndex = 0; // Về "Tất cả"
                isLoaded = true;              // Mở khóa
            }
            // Truyền null vào tham số lopId để BỎ QUA bộ lọc lớp
            LoadDiem(null, kw);
        }

        // Nút Xem chi tiết (Bảng điểm cá nhân)
        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvDanhSachHocSinh.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn học sinh muốn xem chi tiết!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // SỬA 4: Sửa tên cột "mahs" thành "Mã HS"
            int mahs = Convert.ToInt32(dgvDanhSachHocSinh.CurrentRow.Cells["Mã HS"].Value);

            frmbangdiemcanhan frm = new frmbangdiemcanhan();
            frm.MaHocSinh = mahs;
            frm.ShowDialog();

            cboChonLop_SelectedIndexChanged(null, null);
        }

        // Nút Đóng
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Xóa hàm dư thừa này trong Designer
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboChonLop_SelectedIndexChanged(sender, e);
        }
    }
}