﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class frmthongtincanhan : Form
    {
        private int mahs;
        public frmthongtincanhan(int mahs)
        {
            InitializeComponent();
            this.mahs = mahs;
        }

        private void frmthongtincanhan_Load(object sender, EventArgs e)
        {
            SetControlsReadOnly();
            LoadThongTinHocSinh();
            LoadThongTinPhuHuynh();

            LoadHocKyComboBox();

            // Gọi sự kiện chọn Học kỳ (sẽ Load Diem cho lần đầu tiên)
            cboHocKy_SelectedIndexChanged(null, null);
        }

        // Đặt tất cả các control ở chế độ chỉ đọc (Read-Only)
        private void SetControlsReadOnly()
        {
            txtMaHS.ReadOnly = true;
            txtHolot.ReadOnly = true;
            txtTen.ReadOnly = true;
            dtpNgaySinh.Enabled = false; // Dùng Enabled=false cho DateTimePicker
            txtDiaChi.ReadOnly = true;
            cboGioiTinh.Enabled = false; // Dùng Enabled=false cho ComboBox
            txtChucVu.ReadOnly = true;
            txtLop.ReadOnly = true;

            txtTencha.ReadOnly = true;
            txtNghecha.ReadOnly = true;
            txtSDTcha.ReadOnly = true;
            txtDiaChicha.ReadOnly = true;
            txtTenme.ReadOnly = true;
            txtNgheme.ReadOnly = true;
            txtSDTme.ReadOnly = true;
            txtDiaChime.ReadOnly = true;

            txtTrungBinh.ReadOnly = true;
            txtHocLuc.ReadOnly = true;
        }

        private void LoadThongTinHocSinh()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                string sql = @"
                SELECT hs.*, l.tenlop 
                FROM hocsinh hs
                JOIN lop l ON l.id = hs.lop_id
                WHERE hs.mahs = @mahs";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@mahs", mahs);

                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    txtMaHS.Text = rd["mahs"].ToString();
                    txtHolot.Text = rd["holot"].ToString();
                    txtTen.Text = rd["ten"].ToString();

                    // SỬA LỖI 1: Kiểm tra DBNull cho Ngày sinh
                    if (rd["ngaysinh"] != DBNull.Value)
                    {
                        dtpNgaySinh.Value = Convert.ToDateTime(rd["ngaysinh"]);
                    }

                    txtDiaChi.Text = rd["diachi"].ToString();
                    cboGioiTinh.Text = rd["gioitinh"].ToString();
                    txtChucVu.Text = rd["chucvu"].ToString();
                    txtLop.Text = rd["tenlop"].ToString();
                }
            }
        }

        private void LoadThongTinPhuHuynh()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                string sql = "SELECT * FROM phuhuynh WHERE mahs = @mahs";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@mahs", mahs);

                SqlDataReader rd = cmd.ExecuteReader();

                txtTencha.Clear(); txtNghecha.Clear(); txtSDTcha.Clear(); txtDiaChicha.Clear();
                txtTenme.Clear(); txtNgheme.Clear(); txtSDTme.Clear(); txtDiaChime.Clear();

                while (rd.Read())
                {
                    string qh = rd["quanhe"].ToString();
                    if (qh == "Cha")
                    {
                        txtTencha.Text = rd["tenphu"].ToString();
                        txtNghecha.Text = rd["nghenghiep"].ToString();
                        txtSDTcha.Text = rd["sdt"].ToString();
                        txtDiaChicha.Text = rd["diachi"].ToString();
                    }
                    else if (qh == "Mẹ")
                    {
                        txtTenme.Text = rd["tenphu"].ToString();
                        txtNgheme.Text = rd["nghenghiep"].ToString();
                        txtSDTme.Text = rd["sdt"].ToString();
                        txtDiaChime.Text = rd["diachi"].ToString();
                    }
                }
            }
        }
        private void LoadHocKyComboBox()
        {
            // Tạo DataTable thủ công cho ComboBox Học kỳ
            DataTable dtHocKy = new DataTable();
            dtHocKy.Columns.Add("ID", typeof(int));
            dtHocKy.Columns.Add("Name", typeof(string));

            dtHocKy.Rows.Add(1, "Học kỳ 1");
            dtHocKy.Rows.Add(2, "Học kỳ 2");
            dtHocKy.Rows.Add(3, "Cả năm");

            cboHocKy.DataSource = dtHocKy;
            cboHocKy.DisplayMember = "Name";
            cboHocKy.ValueMember = "ID";

            // Mặc định chọn Cả năm để hiển thị tổng quan
            cboHocKy.SelectedValue = 3;
        }
        private void LoadDiem(int mahs, int hocky)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();
                    string sql = "";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    if (hocky == 3) // >> Tính điểm Cả năm (Tổng hợp)
                    {
                        sql = @"
                            SELECT 
                                mh.tenmonhoc AS [Môn học],
                                AVG(CASE WHEN d.hocky = 1 THEN d.dtb_mon END) AS [ĐTB HK1],
                                AVG(CASE WHEN d.hocky = 2 THEN d.dtb_mon END) AS [ĐTB HK2],
                                -- ĐTB Cả Năm tính là AVG của tất cả dtb_mon trong 2 HK (giả định hệ số 1:1:2 cho 3 loại điểm trung bình)
                                (
                                    AVG(CASE WHEN d.hocky = 1 THEN d.dtb_mon END) * 1 + 
                                    AVG(CASE WHEN d.hocky = 2 THEN d.dtb_mon END) * 2
                                ) / 3 AS [ĐTB Cả Năm]
                            FROM diem d
                            JOIN monhoc mh ON mh.id = d.monhoc_id
                            WHERE d.mahs = @mahs AND d.dtb_mon IS NOT NULL 
                            GROUP BY mh.tenmonhoc
                            ORDER BY mh.tenmonhoc";

                        // Xóa các cột cũ để nạp cấu trúc mới
                        dgvBangDiem.Columns.Clear();
                    }
                    else // >> Chỉ xem điểm theo Học kỳ 1 hoặc 2 (Chi tiết điểm thành phần)
                    {
                        sql = @"
                            SELECT 
                                mh.tenmonhoc AS [Môn học],
                                d.mieng AS [Miệng],
                                d.kt_15p AS [KT 15p (1)],
                                d.kt_15p_lan2 AS [KT 15p (2)],
                                d.giua_ky AS [Giữa kỳ],
                                d.cuoi_ky AS [Cuối kỳ],
                                d.dtb_mon AS [ĐTB Môn]
                            FROM diem d
                            JOIN monhoc mh ON mh.id = d.monhoc_id
                            WHERE d.mahs = @mahs AND d.hocky = @hocky
                            ORDER BY mh.tenmonhoc";

                        cmd.Parameters.AddWithValue("@hocky", hocky);
                        // Cần xóa cột khi chuyển từ Cả năm sang HK1/HK2
                        dgvBangDiem.Columns.Clear();
                    }

                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@mahs", mahs);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvBangDiem.DataSource = dt;
                    dgvBangDiem.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dgvBangDiem.RowHeadersVisible = false;

                    // Định dạng cột điểm
                    foreach (DataGridViewColumn col in dgvBangDiem.Columns)
                    {
                        if (hocky == 3) // Định dạng chế độ CẢ NĂM
                        {
                            if (col.Name.Contains("ĐTB"))
                                col.DefaultCellStyle.Format = "N2"; // 2 số thập phân
                        }
                        else // Định dạng chế độ HK1/HK2
                        {
                            if (col.Name == "ĐTB Môn")
                                col.DefaultCellStyle.Format = "N2";
                            else if (col.Name != "Môn học")
                                col.DefaultCellStyle.Format = "N1"; // Điểm thành phần 1 số TP
                        }
                    }

                    dgvBangDiem.ClearSelection();

                    // Tải ĐTB Cả năm và Học lực (thông tin này phải cố định)
                    LoadDTBVaHocLuc(conn, mahs);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tải bảng điểm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void LoadDTBVaHocLuc(SqlConnection conn, int mahs)
        {
            // KHÔNG MỞ CONNECTION VÌ ĐÃ CÓ CONN ĐƯỢC TRUYỀN VÀO TỪ HÀM LoadDiem
            string sql = "SELECT tbcanam, hocluc FROM hocsinh WHERE mahs = @mahs";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@mahs", mahs);

            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                // Kiểm tra DBNull cho Trung bình cả năm
                if (rd["tbcanam"] != DBNull.Value)
                {
                    double dtb = Convert.ToDouble(rd["tbcanam"]);
                    txtTrungBinh.Text = dtb.ToString("0.00");
                }
                else
                {
                    txtTrungBinh.Text = "N/A";
                }

                txtHocLuc.Text = rd["hocluc"] != DBNull.Value ? rd["hocluc"].ToString() : "N/A";
            }
            rd.Close();
        }
        private void panel6_Paint(object sender, PaintEventArgs e)
        {
            // Có thể để trống
        }

        private void btnQuaylai_Click(object sender, EventArgs e)
        {
            // Thêm lệnh đóng Form
            this.Close();
        }

        private void cboHocKy_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Xử lý lỗi InvalidCastException khi form load
            if (cboHocKy.SelectedValue == null) return;

            if (int.TryParse(cboHocKy.SelectedValue.ToString(), out int selectedHocKy))
            {
                LoadDiem(this.mahs, selectedHocKy);
            }
            // Khóa các cột điểm thành phần khi LoadDiem xong
            dgvBangDiem.ClearSelection();
        }
    }
}