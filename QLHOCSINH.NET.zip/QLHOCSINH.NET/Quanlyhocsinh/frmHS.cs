﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // Thư viện kết nối SQL

namespace Quanlyhocsinh
{
    public partial class frmHS : Form
    {
        // Cờ trạng thái
        private bool isAdding = false;
        private bool isLoaded = false; // Biến này để chặn sự kiện combobox chạy khi form chưa load xong
        private int currentTeacherId = 0; // 0 là Admin

        public frmHS()
        {
            InitializeComponent();
        }

        // Nếu bạn có constructor nhận quyền giáo viên
        public frmHS(int teacherId)
        {
            InitializeComponent();
            this.currentTeacherId = teacherId;
        }

        // ==========================================
        // 1. FORM LOAD
        // ==========================================
        private void frmHS_Load(object sender, EventArgs e)
        {
            isLoaded = false; // Tạm khóa
            LoadLopComboBoxes();
            LoadData(); // Load toàn bộ danh sách ban đầu
            SetButtonState(true);
            isLoaded = true; // Mở khóa
        }

        // ==========================================
        // 2. HÀM TẢI DỮ LIỆU (QUAN TRỌNG NHẤT)
        // ==========================================
        private void LoadData(string keyword = null, int? lopId = null)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();

                    // SỬA SQL: JOIN BẢNG LỚP ĐỂ LẤY TÊN LỚP
                    string sqlQuery = @"
                        SELECT 
                            hs.mahs, 
                            hs.holot, 
                            hs.ten, 
                            l.tenlop,   -- Lấy tên lớp hiển thị
                            hs.gioitinh, 
                            hs.ngaysinh, 
                            hs.chucvu, 
                            hs.hanhkiem,
                            hs.lop_id,   -- Lấy ID để xử lý ngầm
                            hs.diachi
                        FROM HocSinh hs
                        LEFT JOIN Lop l ON hs.lop_id = l.id
                        WHERE 1=1";

                    SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                    // --- ƯU TIÊN 1: TÌM KIẾM THEO MÃ HS ---
                    if (!string.IsNullOrEmpty(keyword))
                    {
                        if (int.TryParse(keyword, out int maHSTimKiem))
                        {
                            sqlQuery += " AND hs.mahs = @mahs";
                            cmd.Parameters.AddWithValue("@mahs", maHSTimKiem);
                        }
                    }
                    // --- ƯU TIÊN 2: LỌC THEO LỚP (Chỉ khi không tìm kiếm) ---
                    else if (lopId.HasValue && lopId.Value > 0)
                    {
                        sqlQuery += " AND hs.lop_id = @lopId";
                        cmd.Parameters.AddWithValue("@lopId", lopId.Value);
                    }

                    // --- PHÂN QUYỀN GIÁO VIÊN (Nếu có) ---
                    if (currentTeacherId > 0)
                    {
                        // Chỉ hiện học sinh thuộc lớp giáo viên chủ nhiệm (ví dụ)
                        // Tùy logic của bạn, có thể bỏ qua nếu không cần
                        sqlQuery += " AND hs.lop_id IN (SELECT id FROM lop WHERE magv_chunhiem = @gvId)";
                        cmd.Parameters.AddWithValue("@gvId", currentTeacherId);
                    }

                    cmd.CommandText = sqlQuery;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvHocSinh.DataSource = dt;

                    // --- ĐỊNH DẠNG CỘT HIỂN THỊ ---
                    if (dgvHocSinh.Columns.Contains("lop_id")) dgvHocSinh.Columns["lop_id"].Visible = false; // Ẩn ID
                    if (dgvHocSinh.Columns.Contains("diachi")) dgvHocSinh.Columns["diachi"].Visible = false; // Ẩn Địa chỉ cho gọn

                    dgvHocSinh.Columns["mahs"].HeaderText = "Mã HS";
                    dgvHocSinh.Columns["holot"].HeaderText = "Họ Lót";
                    dgvHocSinh.Columns["ten"].HeaderText = "Tên";

                    if (dgvHocSinh.Columns.Contains("tenlop"))
                    {
                        dgvHocSinh.Columns["tenlop"].HeaderText = "Lớp";
                        dgvHocSinh.Columns["tenlop"].DisplayIndex = 3; // Đưa cột Lớp ra sau Tên
                    }

                    dgvHocSinh.Columns["gioitinh"].HeaderText = "Giới Tính";
                    dgvHocSinh.Columns["ngaysinh"].HeaderText = "Ngày Sinh";
                    dgvHocSinh.Columns["chucvu"].HeaderText = "Chức Vụ";
                    dgvHocSinh.Columns["hanhkiem"].HeaderText = "Hạnh Kiểm";

                    dgvHocSinh.ClearSelection();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
                }
            }
        }
        // ==========================================
        // 3. TẢI COMBOBOX LỚP
        // ==========================================
        private void LoadLopComboBoxes()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();
                    string sql = "SELECT id, tenlop FROM lop ORDER BY tenlop";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // 1. Setup cho ComboBox LỌC (Có thêm dòng "Tất cả")
                    DataTable dtFilter = dt.Copy();
                    DataRow row = dtFilter.NewRow();
                    row["id"] = 0;
                    row["tenlop"] = "--- Tất cả các lớp ---";
                    dtFilter.Rows.InsertAt(row, 0);

                    cboChonlop.DataSource = dtFilter;
                    cboChonlop.DisplayMember = "tenlop";
                    cboChonlop.ValueMember = "id";

                    // 2. Setup cho ComboBox NHẬP LIỆU (Chỉ danh sách lớp thật)
                    cboLop.DataSource = dt;
                    cboLop.DisplayMember = "tenlop";
                    cboLop.ValueMember = "id";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tải lớp: " + ex.Message);
                }
            }
        }
        // ==========================================
        // 4. SỰ KIỆN LỌC KHI CHỌN COMBOBOX
        // ==========================================
        private void cboChonlop_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 1. Chặn sự kiện khi Form chưa tải xong để tránh lỗi
            if (!isLoaded) return;
            // 2. XÓA NỘI DUNG Ô TÌM KIẾM (Theo yêu cầu của bạn)
            // Để người dùng biết là đang lọc theo danh sách lớp chứ không phải tìm kiếm cũ
            txtTimKiem.Text = "";
            // 3. Lấy ID của lớp đang chọn
            int selectedId = 0;
            if (cboChonlop.SelectedValue != null)
            {
                int.TryParse(cboChonlop.SelectedValue.ToString(), out selectedId);
            }
            // 4. Gọi hàm LoadData
            // - Tham số keyword: truyền null (vì đã xóa tìm kiếm)
            // - Tham số lopId: truyền ID lớp vừa chọn
            LoadData(null, selectedId);
        }

        // ==========================================
        // 5. NÚT TÌM KIẾM (CHỈ TÌM MÃ HS)
        // ==========================================
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.Trim();

            // =================================================================
            // TRƯỜNG HỢP 1: Ô TÌM KIẾM RỖNG -> LOAD LẠI THEO LỚP ĐANG CHỌN
            // =================================================================
            if (string.IsNullOrEmpty(keyword))
            {
                // Lấy ID lớp đang chọn hiện tại
                int selectedLopId = 0;
                if (cboChonlop.SelectedValue != null)
                {
                    int.TryParse(cboChonlop.SelectedValue.ToString(), out selectedLopId);
                }

                // Load lại danh sách theo lớp đó (coi như là nút Làm mới)
                LoadData(null, selectedLopId);
                return;
            }

            // =================================================================
            // TRƯỜNG HỢP 2: CÓ NHẬP MÃ -> TÌM TRÊN TOÀN TRƯỜNG
            // =================================================================

            // Kiểm tra phải là số
            if (!int.TryParse(keyword, out int maHS))
            {
                MessageBox.Show("Mã học sinh phải là số!");
                txtTimKiem.Text = "";
                txtTimKiem.Focus();
                return;
            }

            // [QUAN TRỌNG] Reset ComboBox về "Tất cả" để người dùng hiểu là đang tìm toàn trường
            // Phải dùng biến isLoaded chặn sự kiện để không bị load 2 lần
            if (cboChonlop.Items.Count > 0) // Kiểm tra an toàn
            {
                isLoaded = false;            // Khóa sự kiện
                cboChonlop.SelectedIndex = 0; // Chuyển về "Tất cả các lớp"
                isLoaded = true;             // Mở khóa
            }

            // Gọi hàm tìm kiếm (Truyền null vào tham số lớp để tìm tất cả)
            LoadData(keyword, null);
        }

        // ==========================================
        // 6. HIỂN THỊ CHI TIẾT KHI CLICK BẢNG
        // ==========================================
        private void dgvHocSinh_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && btnThem.Enabled == true) // Chỉ cho xem khi không ở chế độ thêm/sửa
            {
                try
                {
                    DataGridViewRow row = dgvHocSinh.Rows[e.RowIndex];
                    // Lấy Mã HS từ cột ẩn hoặc cột hiện
                    int mahs = Convert.ToInt32(row.Cells["mahs"].Value);
                    LoadChiTietHocSinh(mahs);
                }
                catch { }
            }
        }

        private void LoadChiTietHocSinh(int mahs)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();

                // 1. Load thông tin HS
                string sqlHS = "SELECT * FROM hocsinh WHERE mahs = @mahs";
                SqlCommand cmdHS = new SqlCommand(sqlHS, conn);
                cmdHS.Parameters.AddWithValue("@mahs", mahs);
                SqlDataReader rd = cmdHS.ExecuteReader();
                if (rd.Read())
                {
                    txtMaHS.Text = rd["mahs"].ToString();
                    txtHolot.Text = rd["holot"].ToString();
                    txtTen.Text = rd["ten"].ToString();
                    dtpNgaySinh.Value = Convert.ToDateTime(rd["ngaysinh"]);
                    txtDiaChi.Text = rd["diachi"].ToString();
                    cboGioiTinh.Text = rd["gioitinh"].ToString();
                    txtChucVu.Text = rd["chucvu"].ToString();
                    cboLop.SelectedValue = rd["lop_id"];
                }
                rd.Close();

                // 2. Load thông tin Phụ huynh
                ClearParentFields();
                string sqlPH = "SELECT * FROM phuhuynh WHERE mahs = @mahs";
                SqlCommand cmdPH = new SqlCommand(sqlPH, conn);
                cmdPH.Parameters.AddWithValue("@mahs", mahs);
                SqlDataReader rdPH = cmdPH.ExecuteReader();
                while (rdPH.Read())
                {
                    string quanhe = rdPH["quanhe"].ToString();
                    if (quanhe == "Cha")
                    {
                        txtTencha.Text = rdPH["tenphu"].ToString();
                        txtNghecha.Text = rdPH["nghenghiep"].ToString();
                        txtSDTcha.Text = rdPH["sdt"].ToString();
                        txtDiaChicha.Text = rdPH["diachi"].ToString();
                    }
                    else if (quanhe == "Mẹ" || quanhe == "Me")
                    {
                        txtTenme.Text = rdPH["tenphu"].ToString();
                        txtNgheme.Text = rdPH["nghenghiep"].ToString();
                        txtSDTme.Text = rdPH["sdt"].ToString();
                        txtDiaChime.Text = rdPH["diachi"].ToString();
                    }
                }
                rdPH.Close();
            }
        }

        // ==========================================
        // 7. CÁC NÚT THÊM - SỬA - XÓA - LƯU
        // ==========================================
        private void btnThem_Click(object sender, EventArgs e)
        {
            isAdding = true;
            SetButtonState(false);
            ClearAllFields();
            txtMaHS.Text = "[Tự động]";
            txtHolot.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHS.Text) || txtMaHS.Text == "[Tự động]")
            {
                MessageBox.Show("Vui lòng chọn học sinh cần sửa!");
                return;
            }
            isAdding = false;
            SetButtonState(false);
            txtHolot.Focus();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHS.Text) || txtMaHS.Text == "[Tự động]") return;

            if (MessageBox.Show("Bạn có chắc muốn xóa học sinh này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using (SqlConnection conn = KetNoi.GetConnection())
                {
                    conn.Open();
                    // Xóa phụ huynh trước (nếu có khóa ngoại) hoặc xóa HS trực tiếp nếu set Cascade
                    SqlCommand cmd = new SqlCommand("DELETE FROM hocsinh WHERE mahs = @mahs", conn);
                    cmd.Parameters.AddWithValue("@mahs", Convert.ToInt32(txtMaHS.Text));
                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Xóa thành công!");
                        ClearAllFields();
                        LoadData(); // Load lại
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi xóa: " + ex.Message);
                    }
                }
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTen.Text) || cboLop.SelectedValue == null)
            {
                MessageBox.Show("Tên và Lớp không được để trống!");
                return;
            }

            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();
                try
                {
                    int currentMaHS = 0;

                    // 1. XỬ LÝ BẢNG HOCSINH
                    if (isAdding)
                    {
                        string sql = @"INSERT INTO hocsinh (holot, ten, lop_id, gioitinh, ngaysinh, chucvu, diachi) 
                                       VALUES (@holot, @ten, @lopId, @gioitinh, @ngaysinh, @chucvu, @diachi);
                                       SELECT SCOPE_IDENTITY();";
                        SqlCommand cmd = new SqlCommand(sql, conn, trans);
                        cmd.Parameters.AddWithValue("@holot", txtHolot.Text);
                        cmd.Parameters.AddWithValue("@ten", txtTen.Text);
                        cmd.Parameters.AddWithValue("@lopId", cboLop.SelectedValue);
                        cmd.Parameters.AddWithValue("@gioitinh", cboGioiTinh.Text);
                        cmd.Parameters.AddWithValue("@ngaysinh", dtpNgaySinh.Value);
                        cmd.Parameters.AddWithValue("@chucvu", txtChucVu.Text);
                        cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text);

                        currentMaHS = Convert.ToInt32(cmd.ExecuteScalar()); // Lấy ID vừa thêm
                    }
                    else // Sửa
                    {
                        currentMaHS = Convert.ToInt32(txtMaHS.Text);
                        string sql = @"UPDATE hocsinh SET holot=@holot, ten=@ten, lop_id=@lopId, 
                                       gioitinh=@gioitinh, ngaysinh=@ngaysinh, chucvu=@chucvu, diachi=@diachi 
                                       WHERE mahs=@mahs";
                        SqlCommand cmd = new SqlCommand(sql, conn, trans);
                        cmd.Parameters.AddWithValue("@mahs", currentMaHS);
                        cmd.Parameters.AddWithValue("@holot", txtHolot.Text);
                        cmd.Parameters.AddWithValue("@ten", txtTen.Text);
                        cmd.Parameters.AddWithValue("@lopId", cboLop.SelectedValue);
                        cmd.Parameters.AddWithValue("@gioitinh", cboGioiTinh.Text);
                        cmd.Parameters.AddWithValue("@ngaysinh", dtpNgaySinh.Value);
                        cmd.Parameters.AddWithValue("@chucvu", txtChucVu.Text);
                        cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text);
                        cmd.ExecuteNonQuery();
                    }

                    // 2. XỬ LÝ BẢNG PHUHUYNH (CHA)
                    // Logic đơn giản: Xóa cũ thêm mới hoặc Update. Ở đây dùng Update if exists.
                    SavePhuHuynh(conn, trans, currentMaHS, "Cha", txtTencha.Text, txtNghecha.Text, txtSDTcha.Text, txtDiaChicha.Text);

                    // 3. XỬ LÝ BẢNG PHUHUYNH (MẸ)
                    SavePhuHuynh(conn, trans, currentMaHS, "Mẹ", txtTenme.Text, txtNgheme.Text, txtSDTme.Text, txtDiaChime.Text);

                    trans.Commit();
                    MessageBox.Show("Lưu thành công!");
                    SetButtonState(true);

                    // Load lại dữ liệu và focus vào dòng vừa thêm/sửa
                    if (isAdding) ClearAllFields();
                    LoadData();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("Lỗi khi lưu: " + ex.Message);
                }
            }
        }

        // Hàm phụ trợ lưu phụ huynh cho gọn
        private void SavePhuHuynh(SqlConnection conn, SqlTransaction trans, int mahs, string quanhe, string ten, string nghe, string sdt, string diachi)
        {
            if (string.IsNullOrEmpty(ten)) return; // Không nhập tên thì thôi

            string sqlCheck = "SELECT COUNT(*) FROM phuhuynh WHERE mahs = @mahs AND quanhe = @quanhe";
            SqlCommand cmdCheck = new SqlCommand(sqlCheck, conn, trans);
            cmdCheck.Parameters.AddWithValue("@mahs", mahs);
            cmdCheck.Parameters.AddWithValue("@quanhe", quanhe);
            int exists = (int)cmdCheck.ExecuteScalar();

            string sql;
            if (exists > 0)
                sql = "UPDATE phuhuynh SET tenphu=@ten, nghenghiep=@nghe, sdt=@sdt, diachi=@diachi WHERE mahs=@mahs AND quanhe=@quanhe";
            else
                sql = "INSERT INTO phuhuynh (mahs, tenphu, nghenghiep, sdt, diachi, quanhe) VALUES (@mahs, @ten, @nghe, @sdt, @diachi, @quanhe)";

            SqlCommand cmd = new SqlCommand(sql, conn, trans);
            cmd.Parameters.AddWithValue("@mahs", mahs);
            cmd.Parameters.AddWithValue("@quanhe", quanhe);
            cmd.Parameters.AddWithValue("@ten", ten);
            cmd.Parameters.AddWithValue("@nghe", nghe);
            cmd.Parameters.AddWithValue("@sdt", sdt);
            cmd.Parameters.AddWithValue("@diachi", diachi);
            cmd.ExecuteNonQuery();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            isAdding = false;
            SetButtonState(true);
            ClearAllFields();
            if (dgvHocSinh.CurrentRow != null)
            {
                int mahs = Convert.ToInt32(dgvHocSinh.CurrentRow.Cells["mahs"].Value);
                LoadChiTietHocSinh(mahs);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ==========================================
        // 8. CÁC HÀM TIỆN ÍCH UI
        // ==========================================
        private void SetButtonState(bool isViewing)
        {
            btnThem.Enabled = isViewing;
            btnSua.Enabled = isViewing;
            btnXoa.Enabled = isViewing;
            btnLuu.Enabled = !isViewing;
            btnHuy.Enabled = !isViewing;
            btnBack.Enabled = isViewing;

            // Khóa/Mở ô nhập liệu
            txtHolot.ReadOnly = isViewing;
            txtTen.ReadOnly = isViewing;
            txtDiaChi.ReadOnly = isViewing;
            txtChucVu.ReadOnly = isViewing;
            dtpNgaySinh.Enabled = !isViewing;
            cboLop.Enabled = !isViewing;
            cboGioiTinh.Enabled = !isViewing;

            // Phụ huynh
            txtTencha.ReadOnly = isViewing;
            txtNghecha.ReadOnly = isViewing;
            txtSDTcha.ReadOnly = isViewing;
            txtDiaChicha.ReadOnly = isViewing;
            txtTenme.ReadOnly = isViewing;
            txtNgheme.ReadOnly = isViewing;
            txtSDTme.ReadOnly = isViewing;
            txtDiaChime.ReadOnly = isViewing;
        }

        private void ClearAllFields()
        {
            txtMaHS.Text = "";
            txtHolot.Text = "";
            txtTen.Text = "";
            txtDiaChi.Text = "";
            txtChucVu.Text = "";
            cboLop.SelectedIndex = -1;
            cboGioiTinh.SelectedIndex = -1;
            dtpNgaySinh.Value = DateTime.Now;
            ClearParentFields();
        }

        private void ClearParentFields()
        {
            txtTencha.Text = ""; txtNghecha.Text = ""; txtSDTcha.Text = ""; txtDiaChicha.Text = "";
            txtTenme.Text = ""; txtNgheme.Text = ""; txtSDTme.Text = ""; txtDiaChime.Text = "";
        }

        private void btnThongTin_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem có dòng nào đang được chọn không
            if (dgvHocSinh.CurrentRow != null)
            {
                // 1. Lấy Mã Học Sinh từ dòng đang chọn trên lưới (DataGridView)
                // Lưu ý: "mahs" là tên cột trong DataGridView (Name), không phải tiêu đề (HeaderText)
                int mahs = Convert.ToInt32(dgvHocSinh.CurrentRow.Cells["mahs"].Value);

                // 2. Truyền biến mahs vào trong ngoặc
                frmthongtincanhan frm = new frmthongtincanhan(mahs);

                frm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một học sinh trong danh sách!", "Thông báo");
            }
        }
    }
}