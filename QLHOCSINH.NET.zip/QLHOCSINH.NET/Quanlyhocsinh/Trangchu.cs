﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class Trangchu : Form
    {
        // 1. Khai báo 3 biến cấp Class
        private string currentUserRole;
        private string currentUserID;
        private string currentUserFullname; // BIẾN MỚI ĐỂ LƯU TÊN

        // Constructor Mặc định
        public Trangchu()
        {
            InitializeComponent();
        }

        // 2. CONSTRUCTOR CHÍNH (NHẬN 3 THAM SỐ)
        public Trangchu(string role, string userId, string fullname)
        {
            InitializeComponent();

            // Lưu 3 giá trị lại
            this.currentUserRole = role.Trim().ToLower();
            this.currentUserID = userId;
            this.currentUserFullname = fullname;

            PhanQuyenTheoVaiTro();
        }

        // 3. HÀM PHÂN QUYỀN (Hiển thị tên)
        private void PhanQuyenTheoVaiTro()
        {
            // SỬA: Hiển thị tên đầy đủ
            this.Text = $"Trang Chủ (Chào mừng: {this.currentUserFullname})";

            try
            {
                // Logic ẩn/hiện nút
                btnQuanlyhocsinh.Visible = false;
                btnQuanlygiaovien.Visible = false;
                btnTrangchu.Visible = false;
                btnQuanlydiem.Visible = false;
                btnDangxuat.Visible = false;
                btnTKB.Visible = false;

                if (this.currentUserRole == "admin")
                {
                    btnQuanlyhocsinh.Visible = true;
                    btnQuanlygiaovien.Visible = true;
                    btnTrangchu.Visible = true;
                    btnQuanlydiem.Visible = true;
                    btnDangxuat.Visible = true;
                    btnTKB.Visible = true;
                }
                else if (this.currentUserRole == "teacher")
                {
                    btnQuanlyhocsinh.Visible = true;
                    btnQuanlygiaovien.Visible = false;
                    btnTrangchu.Visible = true;
                    btnQuanlydiem.Visible = true;
                    btnDangxuat.Visible = true;
                    btnTKB.Visible = true;
                }
                else if (this.currentUserRole == "student")
                {
                    btnTrangchu.Visible = true;
                    btnQuanlyhocsinh.Visible = true;
                    btnQuanlydiem.Visible = false;
                    btnTKB.Visible = true;
                    btnDangxuat.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi phân quyền nút: " + ex.Message);
            }
        }

        // --- CÁC SỰ KIỆN CLICK (ĐÃ SỬA CHO ADMIN) ---

        private void btnQuanlyhocsinh_Click(object sender, EventArgs e)
        {
            string userIdString = this.currentUserID;

            if (this.currentUserRole == "student")
            {
                if (int.TryParse(userIdString, out int studentId))
                {
                    frmthongtincanhan form = new frmthongtincanhan(studentId);
                    form.Show();
                }
                else
                {
                    MessageBox.Show("Lỗi: Mã học sinh không hợp lệ.", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (this.currentUserRole == "teacher")
            {
                if (int.TryParse(userIdString, out int teacherId))
                {
                    frmHS frmquanlyhocsinh = new frmHS(teacherId);
                    frmquanlyhocsinh.ShowDialog();
                }
            }
            else if (this.currentUserRole == "admin")
            {
                // Admin mở Form quản lý chung
                frmHS frmquanlyhocsinh = new frmHS();
                frmquanlyhocsinh.ShowDialog();
            }
        }

        private void btnQuanlydiem_Click_1(object sender, EventArgs e)
        {
            if (this.currentUserRole == "teacher" && int.TryParse(this.currentUserID, out int teacherId))
            {
                frmQuanLyDiem frmQuanLyDiem = new frmQuanLyDiem(teacherId);
                frmQuanLyDiem.ShowDialog();
            }
            else if (this.currentUserRole == "admin")
            {
                // Admin mở Form quản lý chung
                frmQuanLyDiem frmQuanLyDiem = new frmQuanLyDiem();
                frmQuanLyDiem.ShowDialog();
            }
        }

        private void btnTKB_Click_1(object sender, EventArgs e)
        {
            if (int.TryParse(this.currentUserID, out int userId))
            {
                frmThoikhoabieu frmThoikhoabieu = new frmThoikhoabieu(userId, this.currentUserRole);
                frmThoikhoabieu.ShowDialog();

            }
            else
            {
                MessageBox.Show("Không thể lấy ID người dùng để tải Thời khóa biểu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnQuanlygiaovien_Click_1(object sender, EventArgs e)
        {
            frmQuanLyGiaoVien frmQuanLyGiaoVien = new frmQuanLyGiaoVien();
            frmQuanLyGiaoVien.ShowDialog();
        }

        private void btnDangxuat_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frmDangNhap frmDangNhap = new frmDangNhap();
            frmDangNhap.Show();
        }

        // --- CÁC SỰ KIỆN PHỤ (ĐỂ TRỐNG) ---
        private void Trangchu_Load_1(object sender, EventArgs e) { }
        private void btnTrangchu_Click_1(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
    }
}