﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class frmbangdiemcanhan : Form
    {
        private bool isAdding = false;
        // private bool isLoaded = false; // Đã bỏ dòng này để loại bỏ cảnh báo CS0414 nếu không dùng

        // Lưu ID của dòng điểm đang chọn để sửa/xóa
        private int selectedDiemId = -1;

        // Dùng thuộc tính này để nhận Mã Học sinh từ Form gọi
        public int MaHocSinh { get; set; }

        // Hàm khởi tạo mặc định (VS cần)
        public frmbangdiemcanhan()
        {
            InitializeComponent();
            // Đặt các TextBox thông tin học sinh chỉ hiển thị
            txtTenHocSinh.ReadOnly = true;
            txtTenLop.ReadOnly = true;
        }

        // --- HÀM HỖ TRỢ VÀ TÍNH TOÁN ---

        private float? ConvertToFloat(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return null;

            // Chấp nhận cả dấu phẩy và dấu chấm, và chỉ cho phép giá trị từ 0 đến 10
            if (float.TryParse(text.Replace(",", "."), out float value))
            {
                if (value >= 0 && value <= 10) return value;
            }
            return null;
        }

        private float CalculateDiemTB(float? mieng, float? kt15p1, float? kt15p2, float? giuaKy, float? cuoiKy)
        {
            float sumWeightedScores = (mieng ?? 0) * 1 + (kt15p1 ?? 0) * 1 + (kt15p2 ?? 0) * 1 + (giuaKy ?? 0) * 2 + (cuoiKy ?? 0) * 3;
            int actualTotalWeight = (mieng.HasValue ? 1 : 0) + (kt15p1.HasValue ? 1 : 0) + (kt15p2.HasValue ? 1 : 0) + (giuaKy.HasValue ? 2 : 0) + (cuoiKy.HasValue ? 3 : 0);
            if (actualTotalWeight == 0) return 0f;
            return (float)Math.Round(sumWeightedScores / actualTotalWeight, 1);
        }

        // --- LOAD DỮ LIỆU CƠ SỞ ---

        private void LoadThongTinHocSinh(int mahs)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                string sql = @"
                    SELECT
                    (hs.holot + ' ' + hs.ten) AS [Họ Tên], l.tenlop 
                    FROM hocsinh hs
                    JOIN lop l ON l.id = hs.lop_id
                    WHERE hs.mahs = @mahs";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@mahs", mahs);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtTenHocSinh.Text = reader["Họ Tên"].ToString();
                    txtTenLop.Text = reader["tenlop"].ToString();
                }
                else
                {
                    txtTenHocSinh.Text = "Không tìm thấy học sinh";
                    txtTenLop.Text = "";
                    MessageBox.Show("Không tìm thấy thông tin học sinh với mã " + mahs, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                reader.Close();
            }
        }

        private void LoadMonHoc()
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                conn.Open();
                string sql = "SELECT id, tenmonhoc FROM monhoc ORDER BY tenmonhoc";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cboMonHoc.DataSource = dt;
                cboMonHoc.DisplayMember = "tenmonhoc";
                cboMonHoc.ValueMember = "id";
            }
            cboMonHoc.SelectedIndex = -1;
        }

        // --- LOAD ĐIỂM CỦA HỌC SINH ĐƯỢC TRUYỀN VÀO ---
        private void LoadDiem(int mahs, int hocky) // >> Đã thêm tham số hocky
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();

                    string sql = "";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    if (hocky == 3) // >> Tính điểm Cả năm
                    {
                        sql = @"
                    SELECT 
                        m.tenmonhoc AS [Môn học],
                        AVG(CASE WHEN d.hocky = 1 THEN d.dtb_mon END) AS [ĐTB HK1],
                        AVG(CASE WHEN d.hocky = 2 THEN d.dtb_mon END) AS [ĐTB HK2],
                        AVG(d.dtb_mon) AS [ĐTB Chung]
                    FROM diem d
                    JOIN monhoc m ON m.id = d.monhoc_id
                    WHERE d.mahs = @mahs AND d.dtb_mon IS NOT NULL -- Chỉ tính môn đã có điểm
                    GROUP BY m.tenmonhoc
                    ORDER BY m.tenmonhoc";

                        // Xóa hết các cột cũ để nạp cấu trúc mới
                        dgvDiemCaNhan.Columns.Clear();

                        // Ẩn các nút thao tác khi xem điểm Cả năm
                        SetButtonState(true);
                        btnThem.Enabled = false;
                        btnSua.Enabled = false;
                        btnXoa.Enabled = false;
                    }
                    else // >> Chỉ xem điểm theo Học kỳ 1 hoặc 2
                    {
                        sql = @"
                    SELECT 
                        d.id, -- Phải giữ cột ID để Sửa/Xóa
                        m.tenmonhoc AS [Môn học],
                        d.mieng AS [Miệng],
                        d.kt_15p AS [KT 15p (1)],
                        d.kt_15p_lan2 AS [KT 15p (2)],
                        d.giua_ky AS [Giữa kỳ],
                        d.cuoi_ky AS [Cuối kỳ],
                        d.dtb_mon AS [ĐTB Môn]
                    FROM diem d
                    JOIN monhoc m ON m.id = d.monhoc_id
                    WHERE d.mahs = @mahs AND d.hocky = @hocky -- >> THÊM ĐIỀU KIỆN LỌC HỌC KỲ
                    ORDER BY m.tenmonhoc";

                        cmd.Parameters.AddWithValue("@hocky", hocky);
                        SetButtonState(true); // Mở lại các nút thao tác
                    }

                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@mahs", mahs);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvDiemCaNhan.DataSource = dt;

                    // Định dạng cột
                    if (hocky == 3)
                    {
                        if (dgvDiemCaNhan.Columns.Contains("ĐTB HK1"))
                            dgvDiemCaNhan.Columns["ĐTB HK1"].DefaultCellStyle.Format = "N2";
                        if (dgvDiemCaNhan.Columns.Contains("ĐTB HK2"))
                            dgvDiemCaNhan.Columns["ĐTB HK2"].DefaultCellStyle.Format = "N2";
                        if (dgvDiemCaNhan.Columns.Contains("ĐTB Chung"))
                            dgvDiemCaNhan.Columns["ĐTB Chung"].DefaultCellStyle.Format = "N2"; // Hiển thị 2 số TP
                    }
                    else
                    {
                        // Định dạng điểm thành phần (1 số TP) và ĐTB Môn (2 số TP)
                        foreach (DataGridViewColumn col in dgvDiemCaNhan.Columns)
                        {
                            if (col.Name == "Miệng" || col.Name == "KT 15p (1)" || col.Name == "KT 15p (2)" || col.Name == "Giữa kỳ" || col.Name == "Cuối kỳ")
                            {
                                col.DefaultCellStyle.Format = "N1";
                            }
                            else if (col.Name == "ĐTB Môn")
                            {
                                col.DefaultCellStyle.Format = "N2";
                            }
                        }
                    }

                    if (dt.Columns.Contains("id"))
                        dgvDiemCaNhan.Columns["id"].Visible = false;

                    dgvDiemCaNhan.ClearSelection();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tải bảng điểm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // --- ĐIỀU CHỈNH TRẠNG THÁI FORM ---
        private void SetButtonState(bool view)
        {
            btnThem.Enabled = view;
            // Bật SỬA/XÓA chỉ khi đang ở chế độ VIEW VÀ đã chọn một ID hợp lệ
            btnSua.Enabled = view && (selectedDiemId != -1);
            btnXoa.Enabled = view && (selectedDiemId != -1);

            btnLuu.Enabled = !view;
            btnHuy.Enabled = !view;

            // Bật/tắt các ô nhập điểm
            cboMonHoc.Enabled = !view;
            txtMieng.ReadOnly = view;
            txtKT15p1.ReadOnly = view;
            txtKT15p2.ReadOnly = view;
            txtGiuaKy.ReadOnly = view;
            txtCuoiKy.ReadOnly = view;
        }

        private void ClearInputFields()
        {
            cboMonHoc.SelectedIndex = -1;
            txtMieng.Clear();
            txtKT15p1.Clear();
            txtKT15p2.Clear();
            txtGiuaKy.Clear();
            txtCuoiKy.Clear();
            // CHỈ RESET selectedDiemId khi clear/kết thúc chỉnh sửa
            selectedDiemId = -1;
            SetButtonState(true); // Cập nhật lại trạng thái nút (Sửa/Xóa bị tắt)
        }

        private void frmbangdiemcanhan_Load(object sender, EventArgs e)
        {
            // isLoaded = false; // Bỏ nếu không dùng

            // Kiểm tra MaHocSinh (ID = 0 là không hợp lệ)
            if (MaHocSinh <= 0)
            {
                MessageBox.Show("Mã học sinh không hợp lệ. Vui lòng thử lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            LoadMonHoc();
            LoadThongTinHocSinh(MaHocSinh);
            LoadHocKyComboBox();
            comboBox1_SelectedIndexChanged(null, null);

            // Bổ sung: Tự động chọn dòng đầu tiên nếu có data để hiển thị và kích hoạt nút Sửa/Xóa
            if (dgvDiemCaNhan.Rows.Count > 0)
            {
                // Chọn dòng đầu tiên
                dgvDiemCaNhan.CurrentCell = dgvDiemCaNhan.Rows[0].Cells[1];
                // Gọi sự kiện CellClick để load data và bật nút Sửa/Xóa
                dgvDiemCaNhan_CellClick(null, new DataGridViewCellEventArgs(1, 0)); // giả sử cột 1 là cột Môn học
            }
            else
            {
                ClearInputFields();
            }
                
            SetButtonState(true);
            // isLoaded = true; // Bỏ nếu không dùng
        }

        // --- SỰ KIỆN CELL CLICK (ĐÃ SỬA VÀ THAY THẾ CellContentClick) ---
        private void dgvDiemCaNhan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // 1. Nếu đang ở chế độ Lưu/Hủy (Edit/Add), không làm gì cả
            if (!btnThem.Enabled)
                return;

            // 2. Nếu click vào hàng hợp lệ
            if (e.RowIndex >= 0 && e.RowIndex < dgvDiemCaNhan.Rows.Count)
            {
                DataGridViewRow row = dgvDiemCaNhan.Rows[e.RowIndex];

                // --- Điền dữ liệu và Lưu ID ---
                // Kiểm tra null cho cột ID (Rất quan trọng)
                if (row.Cells["id"].Value != DBNull.Value)
                    selectedDiemId = Convert.ToInt32(row.Cells["id"].Value);
                else
                    selectedDiemId = -1;

                // Kiểm tra giá trị Mon học trước khi gán
                if (row.Cells["Môn học"].Value != DBNull.Value)
                    cboMonHoc.Text = row.Cells["Môn học"].Value.ToString();
                else
                    cboMonHoc.SelectedIndex = -1;


                // Kiểm tra DBNull cho điểm số trước khi gán
                txtMieng.Text = row.Cells["Miệng"].Value != DBNull.Value ? row.Cells["Miệng"].Value.ToString() : "";
                txtKT15p1.Text = row.Cells["KT 15p (1)"].Value != DBNull.Value ? row.Cells["KT 15p (1)"].Value.ToString() : "";
                txtKT15p2.Text = row.Cells["KT 15p (2)"].Value != DBNull.Value ? row.Cells["KT 15p (2)"].Value.ToString() : "";
                txtGiuaKy.Text = row.Cells["Giữa kỳ"].Value != DBNull.Value ? row.Cells["Giữa kỳ"].Value.ToString() : "";
                txtCuoiKy.Text = row.Cells["Cuối kỳ"].Value != DBNull.Value ? row.Cells["Cuối kỳ"].Value.ToString() : "";

                // Gọi SetButtonState(true) để BẬT nút SỬA và XÓA (nếu selectedDiemId != -1)
                SetButtonState(true);
            }
            else
            {
                // Nếu click vào vùng trống, reset
                ClearInputFields();
                SetButtonState(true);
            }
        }

        // --- CÁC NÚT THAO TÁC ---
        private void LoadHocKyComboBox()
        {
            // Tạo DataTable thủ công cho ComboBox Học kỳ
            DataTable dtHocKy = new DataTable();
            dtHocKy.Columns.Add("ID", typeof(int));
            dtHocKy.Columns.Add("Name", typeof(string));

            dtHocKy.Rows.Add(1, "Học kỳ 1");
            dtHocKy.Rows.Add(2, "Học kỳ 2");
            dtHocKy.Rows.Add(3, "Cả năm"); // ID 3 để tính điểm trung bình cả năm

            cboHocKy.DataSource = dtHocKy;
            cboHocKy.DisplayMember = "Name";
            cboHocKy.ValueMember = "ID";

            // Mặc định chọn Học kỳ 1 (ID=1)
            cboHocKy.SelectedValue = 1;
        }
        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (cboMonHoc.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn Môn học.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // >> Bổ sung: Lấy Học kỳ
            int hocky = Convert.ToInt32(cboHocKy.SelectedValue);
            if (hocky == 3) // Không cho Thêm/Sửa khi đang chọn "Cả năm"
            {
                MessageBox.Show("Không thể Thêm/Sửa khi đang xem điểm Cả năm.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Lấy monhoc_id và mahs từ thuộc tính của form
            int mahs = this.MaHocSinh;
            int monhocId = Convert.ToInt32(cboMonHoc.SelectedValue);

            // Chuyển đổi điểm
            float? mieng = ConvertToFloat(txtMieng.Text);
            float? kt15p1 = ConvertToFloat(txtKT15p1.Text);
            float? kt15p2 = ConvertToFloat(txtKT15p2.Text);
            float? giuaKy = ConvertToFloat(txtGiuaKy.Text);
            float? cuoiKy = ConvertToFloat(txtCuoiKy.Text);

            float dtbMon = CalculateDiemTB(mieng, kt15p1, kt15p2, giuaKy, cuoiKy);

           try
               {
                using (SqlConnection conn = KetNoi.GetConnection())
                {
                    conn.Open();
                    if (isAdding)
                    {
                        // >> Sửa Kiểm tra trùng lặp (Thêm điều kiện hocky)
                        string checkSql = "SELECT COUNT(*) FROM diem WHERE mahs = @mahs AND monhoc_id = @monhocId AND hocky = @hocky";
                        SqlCommand checkCmd = new SqlCommand(checkSql, conn);
                        checkCmd.Parameters.AddWithValue("@mahs", mahs);
                        checkCmd.Parameters.AddWithValue("@monhocId", monhocId);
                        checkCmd.Parameters.AddWithValue("@hocky", hocky);

                        if ((int)checkCmd.ExecuteScalar() > 0)
                        {
                            MessageBox.Show("Điểm cho môn học này đã tồn tại trong học kỳ này. Vui lòng sử dụng chức năng Sửa.", "Lỗi trùng lặp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // >> Sửa INSERT (Thêm hocky)
                        string sqlAdd = @"
                            INSERT INTO diem (mahs, monhoc_id, mieng, kt_15p, kt_15p_lan2, giua_ky, cuoi_ky, dtb_mon, hocky)
                            VALUES (@mahs, @monhocId, @mieng, @kt15p1, @kt15p2, @giuaKy, @cuoiKy, @dtbMon, @hocky)";

                        SqlCommand cmd = new SqlCommand(sqlAdd, conn);
                        cmd.Parameters.AddWithValue("@mahs", mahs);
                        cmd.Parameters.AddWithValue("@monhocId", monhocId);

                        cmd.Parameters.AddWithValue("@mieng", (object)mieng ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@kt15p1", (object)kt15p1 ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@kt15p2", (object)kt15p2 ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@giuaKy", (object)giuaKy ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@cuoiKy", (object)cuoiKy ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@dtbMon", dtbMon);
                        cmd.Parameters.AddWithValue("@hocky", hocky); // >> THAM SỐ HỌC KỲ ĐÃ ĐƯỢC THÊM

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Thêm điểm thành công!");
                    }
                    else // Chức năng Sửa
                    {
                        if (selectedDiemId == -1)
                        {
                            MessageBox.Show("Không có môn học nào được chọn để sửa.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        string sqlUpdate = @"
                                UPDATE diem SET
                                    mieng = @mieng,
                                    kt_15p = @kt15p1,
                                    kt_15p_lan2 = @kt15p2,
                                    giua_ky = @giuaKy,
                                    cuoi_ky = @cuoiKy,
                                    dtb_mon = @dtbMon
                                WHERE id = @id";

                        SqlCommand cmd = new SqlCommand(sqlUpdate, conn);
                        cmd.Parameters.AddWithValue("@id", selectedDiemId);

                        cmd.Parameters.AddWithValue("@mieng", (object)mieng ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@kt15p1", (object)kt15p1 ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@kt15p2", (object)kt15p2 ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@giuaKy", (object)giuaKy ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@cuoiKy", (object)cuoiKy ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@dtbMon", dtbMon);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Cập nhật điểm thành công!");
                    }

                    isAdding = false;
                    ClearInputFields(); // Dùng ClearInputFields để reset selectedDiemId và trạng thái nút
                    LoadDiem(mahs, hocky); // >> Đã thêm tham số hocky

                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Lỗi SQL: " + sqlex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (selectedDiemId == -1)
            {
                MessageBox.Show("Chọn điểm môn học muốn xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa điểm môn này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;

            try
            {
                using (SqlConnection conn = KetNoi.GetConnection())
                {
                    conn.Open();
                    string sql = "DELETE FROM diem WHERE id = @id";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@id", selectedDiemId);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Xóa thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa điểm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            int hocky = Convert.ToInt32(cboHocKy.SelectedValue);
            LoadDiem(this.MaHocSinh, hocky); // >> Đã thêm tham số hocky
            ClearInputFields();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            isAdding = true;
            ClearInputFields();
            SetButtonState(false);
            cboMonHoc.Enabled = true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (selectedDiemId == -1)
            {
                MessageBox.Show("Vui lòng chọn môn học cần sửa trong bảng.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            isAdding = false;
            SetButtonState(false);
            // Ngăn người dùng sửa môn học khi sửa điểm
            cboMonHoc.Enabled = false;
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            isAdding = false;
            ClearInputFields();
            SetButtonState(true);

            // >> Load lại điểm của Học kỳ đang chọn
            int hocky = Convert.ToInt32(cboHocKy.SelectedValue);
            LoadDiem(this.MaHocSinh, hocky);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 1. Kiểm tra SelectedValue là null (trường hợp khởi tạo)
            if (cboHocKy.SelectedValue == null)
            {
                return;
            }

            // 2. Ép kiểu SelectedValue một cách an toàn
            // Đảm bảo rằng SelectedValue có thể chuyển đổi thành int (giả định cột ID là INT)
            if (int.TryParse(cboHocKy.SelectedValue.ToString(), out int selectedHocKy))
            {
                // >> Gọi hàm LoadDiem mới
                LoadDiem(this.MaHocSinh, selectedHocKy);

                ClearInputFields();

                // Bổ sung: Tự động chọn dòng đầu tiên nếu có data để kích hoạt nút Sửa/Xóa (chỉ áp dụng cho HK1/HK2)
                if (dgvDiemCaNhan.Rows.Count > 0 && selectedHocKy != 3)
                {
                    dgvDiemCaNhan.CurrentCell = dgvDiemCaNhan.Rows[0].Cells[1];
                    dgvDiemCaNhan_CellClick(null, new DataGridViewCellEventArgs(1, 0));
                }
            }
            // Nếu không parse được (lỗi DataRowView), ta bỏ qua, tránh crash.
        }
    }
}