﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class frmDangNhap : Form
    {
        // Chuỗi kết nối (Giữ nguyên của bạn)
        private readonly string connectionString = "Server=MSI\\MSSQL;Database=qlhs;Integrated Security=True;";

        public frmDangNhap()
        {
            InitializeComponent();
        }

        // --- SỰ KIỆN 1: FORM LOAD (Khớp với dòng code bạn vừa gửi) ---
        private void frmDangNhap_Load(object sender, EventArgs e)
        {
            // Khi form hiện lên thì con trỏ chuột nằm ở ô Tên đăng nhập
            txtTendangnhap.Select();
        }

        // --- SỰ KIỆN 2: NÚT ĐĂNG NHẬP ---
        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            // 1. Kiểm tra nhập liệu (Giữ nguyên)
            string tenDangNhap = txtTendangnhap.Text.Trim();
            string matKhau = txtMatkhau.Text.Trim();

            if (string.IsNullOrEmpty(tenDangNhap) || string.IsNullOrEmpty(matKhau))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // 2. Lấy thông tin cơ bản từ bảng USERS
                    string sqlCheck = "SELECT id, role, fullname FROM dbo.users WHERE username = @User AND password = @Pass";

                    string userRole = "";
                    string userFullname = "";
                    string realID = "";

                    using (SqlCommand cmd = new SqlCommand(sqlCheck, conn))
                    {
                        cmd.Parameters.AddWithValue("@User", tenDangNhap);
                        cmd.Parameters.AddWithValue("@Pass", matKhau);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                userRole = reader["role"].ToString().Trim();
                                userFullname = reader["fullname"].ToString();
                                realID = reader["id"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu!");
                                return;
                            }
                        }
                    }

                    // 3. XỬ LÝ PHÂN BIỆT: GIÁO VIÊN DÙNG 'HOTEN' - HỌC SINH DÙNG 'HOLOT + TEN'
                    if (userRole == "teacher")
                    {
                        // Bảng GIAOVIEN dùng cột 'hoten'
                        string sqlGetGV = "SELECT magv FROM giaovien WHERE hoten = @TenGV";
                        using (SqlCommand cmdGV = new SqlCommand(sqlGetGV, conn))
                        {
                            cmdGV.Parameters.AddWithValue("@TenGV", userFullname);
                            object result = cmdGV.ExecuteScalar();
                            if (result != null) realID = result.ToString();
                        }
                    }
                    else if (userRole == "student")
                    {
                        // Bảng HOCSINH dùng 'holot' + 'ten'
                        string sqlGetHS = "SELECT mahs FROM hocsinh WHERE (holot + ' ' + ten) = @TenHS";
                        using (SqlCommand cmdHS = new SqlCommand(sqlGetHS, conn))
                        {
                            cmdHS.Parameters.AddWithValue("@TenHS", userFullname);
                            object result = cmdHS.ExecuteScalar();
                            if (result != null) realID = result.ToString();
                        }
                    }

                    // 4. Chuyển Form
                    this.Hide();
                    Trangchu frmMain = new Trangchu(userRole, realID, userFullname);
                    frmMain.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
        }
        private void btnThoat_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi ứng dụng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}