﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanlyhocsinh
{
    public partial class frmQuanLyGiaoVien : Form
    {
        private bool isAdding = false;

        public frmQuanLyGiaoVien()
        {
            InitializeComponent();
        }

        private void frmQuanLyGiaoVien_Load(object sender, EventArgs e)
        {
            LoadData();
            SetButtonState(true);

            dgvGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvGV.MultiSelect = false;
            this.dgvGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGV_CellClick_1);
        }

        // ==========================================
        // 1. LOAD DANH SÁCH GIÁO VIÊN (SỬA LOGIC TÌM MÃ)
        // ==========================================
        private void LoadData(string keyword = null)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();

                    string sqlQuery = @"
                        SELECT magv, hoten, chuyenmon, chunhiemlop, sodt
                        FROM giaovien
                        WHERE 1 = 1";

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    // --- LOGIC TÌM KIẾM THEO MÃ GV ---
                    if (!string.IsNullOrEmpty(keyword))
                    {
                        // Kiểm tra nếu là số thì tìm theo Mã
                        if (int.TryParse(keyword, out int maGVTimKiem))
                        {
                            sqlQuery += " AND magv = @maGV";
                            cmd.Parameters.AddWithValue("@maGV", maGVTimKiem);
                        }
                        else
                        {
                            // Nếu nhập chữ -> Không tìm thấy kết quả nào
                            sqlQuery += " AND 1 = 0";
                        }
                    }
                    // ----------------------------------

                    cmd.CommandText = sqlQuery;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvGV.DataSource = dt;
                    dgvGV.ClearSelection();

                    // Đặt tên cột hiển thị
                    dgvGV.Columns["magv"].HeaderText = "Mã GV";
                    dgvGV.Columns["hoten"].HeaderText = "Họ tên";
                    dgvGV.Columns["chuyenmon"].HeaderText = "Chuyên môn";
                    dgvGV.Columns["chunhiemlop"].HeaderText = "Chủ nhiệm lớp";
                    dgvGV.Columns["sodt"].HeaderText = "Số điện thoại";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
                }
            }
        }

        // ============================
        // 2. LOAD CHI TIẾT LÊN TEXTBOX
        // ============================
        private void LoadChiTietGV(int magv)
        {
            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();
                    string sql = "SELECT * FROM giaovien WHERE magv = @magv";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@magv", magv);

                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.Read())
                    {
                        txtMaGV.Text = rd["magv"].ToString();
                        txtHoTenGV.Text = rd["hoten"].ToString();
                        txtChuyenMon.Text = rd["chuyenmon"] != DBNull.Value ? rd["chuyenmon"].ToString() : "";
                        txtChuNhiem.Text = rd["chunhiemlop"] != DBNull.Value ? rd["chunhiemlop"].ToString() : "";
                        txtSDT.Text = rd["sodt"] != DBNull.Value ? rd["sodt"].ToString() : "";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tải chi tiết: " + ex.Message);
                }
            }
        }

        // ============================
        // 3. CÁC HÀM HỖ TRỢ (UI)
        // ============================
        private void SetButtonState(bool isViewing)
        {
            btnThem.Enabled = isViewing;
            btnSua.Enabled = isViewing;
            btnXoa.Enabled = isViewing;
            btnBack.Enabled = isViewing;
            btnLuu.Enabled = !isViewing;
            btnHuy.Enabled = !isViewing; // Đảm bảo nút Hủy sáng khi đang thêm/sửa

            txtHoTenGV.ReadOnly = isViewing;
            txtChuyenMon.ReadOnly = isViewing;
            txtChuNhiem.ReadOnly = isViewing;
            txtSDT.ReadOnly = isViewing;

            txtMaGV.ReadOnly = true;
        }

        private void ClearAllFields()
        {
            txtMaGV.Text = "";
            txtHoTenGV.Text = "";
            txtChuyenMon.Text = "";
            txtChuNhiem.Text = "";
            txtSDT.Text = "";
        }

        // ============================
        // 4. SỰ KIỆN CLICK GRID
        // ============================
        private void dgvGV_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (btnLuu.Enabled == true) return; // Đang thêm/sửa thì không cho chọn dòng khác

            if (e.RowIndex >= 0)
            {
                try
                {
                    if (dgvGV.Rows[e.RowIndex].Cells["magv"].Value != DBNull.Value)
                    {
                        int magv = Convert.ToInt32(dgvGV.Rows[e.RowIndex].Cells["magv"].Value);
                        LoadChiTietGV(magv);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi chọn dòng: " + ex.Message);
                }
            }
        }

        // ============================
        // 5. CÁC NÚT CHỨC NĂNG CHÍNH
        // ============================
        private void btnThem_Click(object sender, EventArgs e)
        {
            isAdding = true;
            SetButtonState(false);
            ClearAllFields();
            txtMaGV.Text = "[Tự động]";
            txtHoTenGV.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaGV.Text) || txtMaGV.Text == "[Tự động]")
            {
                MessageBox.Show("Vui lòng chọn giáo viên để sửa!");
                return;
            }

            isAdding = false;
            SetButtonState(false);
            txtHoTenGV.Focus();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaGV.Text) || txtMaGV.Text == "[Tự động]")
            {
                MessageBox.Show("Chọn giáo viên cần xóa!");
                return;
            }

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa giáo viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using (SqlConnection conn = KetNoi.GetConnection())
                {
                    try
                    {
                        conn.Open();
                        string sql = "DELETE FROM giaovien WHERE magv = @magv";
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@magv", Convert.ToInt32(txtMaGV.Text));
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Xóa thành công!");
                        LoadData();
                        ClearAllFields();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi xóa (có thể giáo viên này đang chủ nhiệm lớp hoặc có dữ liệu liên quan): " + ex.Message);
                    }
                }
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHoTenGV.Text))
            {
                MessageBox.Show("Tên giáo viên không được trống!");
                return;
            }

            using (SqlConnection conn = KetNoi.GetConnection())
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    if (isAdding)
                    {
                        cmd.CommandText = @"INSERT INTO giaovien (hoten, chuyenmon, chunhiemlop, sodt) VALUES (@hoten, @chuyenmon, @chunhiem, @sodt)";
                    }
                    else
                    {
                        cmd.CommandText = @"UPDATE giaovien SET hoten=@hoten, chuyenmon=@chuyenmon, chunhiemlop=@chunhiem, sodt=@sodt WHERE magv=@magv";
                        cmd.Parameters.AddWithValue("@magv", txtMaGV.Text);
                    }

                    cmd.Parameters.AddWithValue("@hoten", txtHoTenGV.Text);
                    cmd.Parameters.AddWithValue("@chuyenmon", txtChuyenMon.Text);
                    cmd.Parameters.AddWithValue("@chunhiem", txtChuNhiem.Text);
                    cmd.Parameters.AddWithValue("@sodt", txtSDT.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Lưu thành công!");
                    SetButtonState(true);
                    LoadData();

                    // Nếu vừa thêm mới xong, xóa trắng để đẹp
                    if (isAdding) ClearAllFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi lưu: " + ex.Message);
                }
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            isAdding = false;
            SetButtonState(true);
            ClearAllFields();

            // Nếu đang chọn dòng nào thì load lại dòng đó
            if (dgvGV.CurrentRow != null)
            {
                int rowIndex = dgvGV.CurrentRow.Index;
                dgvGV_CellClick_1(dgvGV, new DataGridViewCellEventArgs(0, rowIndex));
            }
        }

        // ==========================================
        // 6. NÚT TÌM KIẾM (ĐÃ SỬA CHỈ TÌM MÃ)
        // ==========================================
        private void button1_Click(object sender, EventArgs e)
        {
            string keyword = textBox1.Text.Trim(); // Giả sử tên ô nhập là textBox1

            // TRƯỜNG HỢP 1: Nếu ô tìm kiếm RỖNG -> Load lại tất cả
            if (string.IsNullOrEmpty(keyword))
            {
                LoadData(); // Gọi hàm không tham số để lấy toàn bộ danh sách
                return;
            }

            // TRƯỜNG HỢP 2: Nếu có nhập gì đó -> Kiểm tra phải là số không
            if (!int.TryParse(keyword, out int checkNum))
            {
                MessageBox.Show("Mã Giáo viên phải là số để tìm kiếm!", "Lỗi");
                textBox1.Focus();
                return;
            }

            // TRƯỜNG HỢP 3: Tìm theo mã
            LoadData(keyword);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}