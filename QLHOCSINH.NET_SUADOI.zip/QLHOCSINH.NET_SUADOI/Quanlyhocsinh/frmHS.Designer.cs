﻿namespace Quanlyhocsinh
{
    partial class frmHS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtDiaChime = new System.Windows.Forms.TextBox();
            this.txtSDTme = new System.Windows.Forms.TextBox();
            this.txtNgheme = new System.Windows.Forms.TextBox();
            this.txtTenme = new System.Windows.Forms.TextBox();
            this.txtDiaChicha = new System.Windows.Forms.TextBox();
            this.txtSDTcha = new System.Windows.Forms.TextBox();
            this.txtNghecha = new System.Windows.Forms.TextBox();
            this.txtTencha = new System.Windows.Forms.TextBox();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtHolot = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtMaHS = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cboChonlop = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvHocSinh = new System.Windows.Forms.DataGridView();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.panelbot = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnThongTin = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.cboLop = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocSinh)).BeginInit();
            this.panelHeader.SuspendLayout();
            this.panelbot.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTimKiem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTimKiem.Location = new System.Drawing.Point(1120, 57);
            this.btnTimKiem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(105, 38);
            this.btnTimKiem.TabIndex = 5;
            this.btnTimKiem.Text = "Tìm Kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = false;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.Location = new System.Drawing.Point(1109, 44);
            this.btnLuu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(116, 42);
            this.btnLuu.TabIndex = 47;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.Location = new System.Drawing.Point(1109, 99);
            this.btnSua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(116, 42);
            this.btnSua.TabIndex = 46;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.Location = new System.Drawing.Point(1001, 99);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(105, 42);
            this.btnXoa.TabIndex = 45;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.Location = new System.Drawing.Point(1001, 44);
            this.btnThem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(105, 42);
            this.btnThem.TabIndex = 44;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // txtDiaChime
            // 
            this.txtDiaChime.Location = new System.Drawing.Point(636, 239);
            this.txtDiaChime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChime.Name = "txtDiaChime";
            this.txtDiaChime.Size = new System.Drawing.Size(275, 26);
            this.txtDiaChime.TabIndex = 43;
            // 
            // txtSDTme
            // 
            this.txtSDTme.Location = new System.Drawing.Point(636, 210);
            this.txtSDTme.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSDTme.Name = "txtSDTme";
            this.txtSDTme.Size = new System.Drawing.Size(275, 26);
            this.txtSDTme.TabIndex = 42;
            // 
            // txtNgheme
            // 
            this.txtNgheme.Location = new System.Drawing.Point(636, 181);
            this.txtNgheme.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNgheme.Name = "txtNgheme";
            this.txtNgheme.Size = new System.Drawing.Size(275, 26);
            this.txtNgheme.TabIndex = 41;
            // 
            // txtTenme
            // 
            this.txtTenme.Location = new System.Drawing.Point(636, 152);
            this.txtTenme.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenme.Name = "txtTenme";
            this.txtTenme.Size = new System.Drawing.Size(275, 26);
            this.txtTenme.TabIndex = 40;
            // 
            // txtDiaChicha
            // 
            this.txtDiaChicha.Location = new System.Drawing.Point(636, 125);
            this.txtDiaChicha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChicha.Name = "txtDiaChicha";
            this.txtDiaChicha.Size = new System.Drawing.Size(275, 26);
            this.txtDiaChicha.TabIndex = 39;
            // 
            // txtSDTcha
            // 
            this.txtSDTcha.Location = new System.Drawing.Point(636, 98);
            this.txtSDTcha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSDTcha.Name = "txtSDTcha";
            this.txtSDTcha.Size = new System.Drawing.Size(275, 26);
            this.txtSDTcha.TabIndex = 38;
            // 
            // txtNghecha
            // 
            this.txtNghecha.Location = new System.Drawing.Point(636, 69);
            this.txtNghecha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNghecha.Name = "txtNghecha";
            this.txtNghecha.Size = new System.Drawing.Size(275, 26);
            this.txtNghecha.TabIndex = 37;
            // 
            // txtTencha
            // 
            this.txtTencha.Location = new System.Drawing.Point(636, 41);
            this.txtTencha.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTencha.Name = "txtTencha";
            this.txtTencha.Size = new System.Drawing.Size(275, 26);
            this.txtTencha.TabIndex = 36;
            // 
            // txtChucVu
            // 
            this.txtChucVu.Location = new System.Drawing.Point(150, 239);
            this.txtChucVu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(284, 26);
            this.txtChucVu.TabIndex = 35;
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(150, 181);
            this.txtTen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(284, 26);
            this.txtTen.TabIndex = 34;
            // 
            // txtHolot
            // 
            this.txtHolot.Location = new System.Drawing.Point(150, 69);
            this.txtHolot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtHolot.Name = "txtHolot";
            this.txtHolot.Size = new System.Drawing.Size(284, 26);
            this.txtHolot.TabIndex = 33;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(150, 125);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(284, 26);
            this.txtDiaChi.TabIndex = 32;
            // 
            // cboGioiTinh
            // 
            this.cboGioiTinh.FormattingEnabled = true;
            this.cboGioiTinh.Location = new System.Drawing.Point(150, 209);
            this.cboGioiTinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboGioiTinh.Name = "cboGioiTinh";
            this.cboGioiTinh.Size = new System.Drawing.Size(284, 28);
            this.cboGioiTinh.TabIndex = 31;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Location = new System.Drawing.Point(150, 98);
            this.dtpNgaySinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(284, 26);
            this.dtpNgaySinh.TabIndex = 30;
            // 
            // txtMaHS
            // 
            this.txtMaHS.Location = new System.Drawing.Point(150, 41);
            this.txtMaHS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaHS.Name = "txtMaHS";
            this.txtMaHS.Size = new System.Drawing.Size(284, 26);
            this.txtMaHS.TabIndex = 28;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label25.Location = new System.Drawing.Point(651, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(210, 25);
            this.label25.TabIndex = 27;
            this.label25.Text = "Thông tin phụ huynh";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(68, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "Họ lót:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(530, 184);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(103, 20);
            this.label23.TabIndex = 24;
            this.label23.Text = "Nghề nghiệp:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(530, 212);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(45, 20);
            this.label22.TabIndex = 23;
            this.label22.Text = "SDT:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(530, 72);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 20);
            this.label14.TabIndex = 24;
            this.label14.Text = "Nghề nghiệp:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(530, 242);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(61, 20);
            this.label21.TabIndex = 22;
            this.label21.Text = "Địa chỉ:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(530, 100);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 20);
            this.label18.TabIndex = 23;
            this.label18.Text = "SDT:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(530, 128);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 20);
            this.label19.TabIndex = 22;
            this.label19.Text = "Địa chỉ:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(530, 156);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 20);
            this.label17.TabIndex = 18;
            this.label17.Text = "Tên mẹ:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(68, 128);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 20);
            this.label12.TabIndex = 9;
            this.label12.Text = "Địa chỉ:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(68, 242);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 20);
            this.label24.TabIndex = 8;
            this.label24.Text = "Chức vụ:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(68, 212);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 20);
            this.label20.TabIndex = 7;
            this.label20.Text = "Giới tính:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(68, 156);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 20);
            this.label16.TabIndex = 6;
            this.label16.Text = "Lớp:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(68, 184);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 20);
            this.label15.TabIndex = 4;
            this.label15.Text = "Tên:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(68, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 20);
            this.label8.TabIndex = 5;
            this.label8.Text = "Ngày sinh:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mã HS:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(165, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "Thông tin học sinh";
            // 
            // cboChonlop
            // 
            this.cboChonlop.FormattingEnabled = true;
            this.cboChonlop.Location = new System.Drawing.Point(90, 64);
            this.cboChonlop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboChonlop.Name = "cboChonlop";
            this.cboChonlop.Size = new System.Drawing.Size(179, 28);
            this.cboChonlop.TabIndex = 2;
            this.cboChonlop.SelectedIndexChanged += new System.EventHandler(this.cboChonlop_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(10, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Chọn lớp:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(470, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ HỌC SINH";
            // 
            // dgvHocSinh
            // 
            this.dgvHocSinh.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvHocSinh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHocSinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHocSinh.Location = new System.Drawing.Point(0, 100);
            this.dgvHocSinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvHocSinh.Name = "dgvHocSinh";
            this.dgvHocSinh.RowHeadersWidth = 62;
            this.dgvHocSinh.RowTemplate.Height = 28;
            this.dgvHocSinh.Size = new System.Drawing.Size(1280, 334);
            this.dgvHocSinh.TabIndex = 11;
            this.dgvHocSinh.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHocSinh_CellClick);
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.Gainsboro;
            this.panelHeader.Controls.Add(this.txtTimKiem);
            this.panelHeader.Controls.Add(this.btnTimKiem);
            this.panelHeader.Controls.Add(this.label2);
            this.panelHeader.Controls.Add(this.label1);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panelHeader.ForeColor = System.Drawing.SystemColors.Highlight;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1280, 100);
            this.panelHeader.TabIndex = 10;
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTimKiem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtTimKiem.Location = new System.Drawing.Point(895, 62);
            this.txtTimKiem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTimKiem.Multiline = true;
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(220, 28);
            this.txtTimKiem.TabIndex = 50;
            // 
            // panelbot
            // 
            this.panelbot.BackColor = System.Drawing.Color.Gainsboro;
            this.panelbot.Controls.Add(this.btnBack);
            this.panelbot.Controls.Add(this.btnHuy);
            this.panelbot.Controls.Add(this.btnThongTin);
            this.panelbot.Controls.Add(this.label7);
            this.panelbot.Controls.Add(this.cboLop);
            this.panelbot.Controls.Add(this.btnLuu);
            this.panelbot.Controls.Add(this.btnSua);
            this.panelbot.Controls.Add(this.btnXoa);
            this.panelbot.Controls.Add(this.btnThem);
            this.panelbot.Controls.Add(this.txtDiaChime);
            this.panelbot.Controls.Add(this.txtSDTme);
            this.panelbot.Controls.Add(this.txtNgheme);
            this.panelbot.Controls.Add(this.txtTenme);
            this.panelbot.Controls.Add(this.txtDiaChicha);
            this.panelbot.Controls.Add(this.txtSDTcha);
            this.panelbot.Controls.Add(this.txtNghecha);
            this.panelbot.Controls.Add(this.txtTencha);
            this.panelbot.Controls.Add(this.txtChucVu);
            this.panelbot.Controls.Add(this.txtTen);
            this.panelbot.Controls.Add(this.txtHolot);
            this.panelbot.Controls.Add(this.txtDiaChi);
            this.panelbot.Controls.Add(this.cboGioiTinh);
            this.panelbot.Controls.Add(this.dtpNgaySinh);
            this.panelbot.Controls.Add(this.txtMaHS);
            this.panelbot.Controls.Add(this.label25);
            this.panelbot.Controls.Add(this.label6);
            this.panelbot.Controls.Add(this.label23);
            this.panelbot.Controls.Add(this.label22);
            this.panelbot.Controls.Add(this.label14);
            this.panelbot.Controls.Add(this.label21);
            this.panelbot.Controls.Add(this.label18);
            this.panelbot.Controls.Add(this.label19);
            this.panelbot.Controls.Add(this.label17);
            this.panelbot.Controls.Add(this.label12);
            this.panelbot.Controls.Add(this.label24);
            this.panelbot.Controls.Add(this.label20);
            this.panelbot.Controls.Add(this.label16);
            this.panelbot.Controls.Add(this.label15);
            this.panelbot.Controls.Add(this.label8);
            this.panelbot.Controls.Add(this.label5);
            this.panelbot.Controls.Add(this.label4);
            this.panelbot.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelbot.Location = new System.Drawing.Point(0, 434);
            this.panelbot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelbot.Name = "panelbot";
            this.panelbot.Size = new System.Drawing.Size(1280, 280);
            this.panelbot.TabIndex = 12;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(1109, 209);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(116, 42);
            this.btnBack.TabIndex = 53;
            this.btnBack.Text = "Quay lại";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnHuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.Location = new System.Drawing.Point(1001, 209);
            this.btnHuy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(105, 42);
            this.btnHuy.TabIndex = 52;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = false;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnThongTin
            // 
            this.btnThongTin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnThongTin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongTin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnThongTin.Location = new System.Drawing.Point(1001, 154);
            this.btnThongTin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThongTin.Name = "btnThongTin";
            this.btnThongTin.Size = new System.Drawing.Size(224, 43);
            this.btnThongTin.TabIndex = 51;
            this.btnThongTin.Text = "Thông tin chi tiết";
            this.btnThongTin.UseVisualStyleBackColor = false;
            this.btnThongTin.Click += new System.EventHandler(this.btnThongTin_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(531, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 20);
            this.label7.TabIndex = 50;
            this.label7.Text = "Tên cha:";
            // 
            // cboLop
            // 
            this.cboLop.FormattingEnabled = true;
            this.cboLop.Location = new System.Drawing.Point(150, 152);
            this.cboLop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboLop.Name = "cboLop";
            this.cboLop.Size = new System.Drawing.Size(284, 28);
            this.cboLop.TabIndex = 49;
            // 
            // frmHS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 714);
            this.Controls.Add(this.dgvHocSinh);
            this.Controls.Add(this.panelbot);
            this.Controls.Add(this.cboChonlop);
            this.Controls.Add(this.panelHeader);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmHS";
            this.Text = "frmHS";
            this.Load += new System.EventHandler(this.frmHS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocSinh)).EndInit();
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelbot.ResumeLayout(false);
            this.panelbot.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.TextBox txtDiaChime;
        private System.Windows.Forms.TextBox txtSDTme;
        private System.Windows.Forms.TextBox txtNgheme;
        private System.Windows.Forms.TextBox txtTenme;
        private System.Windows.Forms.TextBox txtDiaChicha;
        private System.Windows.Forms.TextBox txtSDTcha;
        private System.Windows.Forms.TextBox txtNghecha;
        private System.Windows.Forms.TextBox txtTencha;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtHolot;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtMaHS;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboChonlop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvHocSinh;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Panel panelbot;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.ComboBox cboLop;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnThongTin;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnBack;
    }
}